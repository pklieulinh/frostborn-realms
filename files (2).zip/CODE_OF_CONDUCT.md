# Code of Conduct

We foster a respectful, inclusive environment.

## Standards
- Be courteous in feedback
- Assume positive intent
- No harassment or discrimination

## Enforcement
Report issues; repeated violations lead to removal from collaboration.

## Scope
All project spaces (issues, PRs, discussions).