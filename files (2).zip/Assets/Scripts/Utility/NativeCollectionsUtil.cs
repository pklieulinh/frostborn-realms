namespace FrostbornRealms.Utility {
    public static class NativeCollectionsUtil {
        // Placeholder for future alloc helpers / safety wrappers.
    }
}