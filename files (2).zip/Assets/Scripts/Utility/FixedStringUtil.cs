namespace FrostbornRealms.Utility {
    public static class FixedStringUtil {
        // Placeholder for FixedString <-> string conversions if needed.
    }
}