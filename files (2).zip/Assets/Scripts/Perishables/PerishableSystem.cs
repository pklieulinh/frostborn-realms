using Unity.Entities;
using FrostbornRealms.Perishables;
using FrostbornRealms.Inventory;
using FrostbornRealms.Core;
using Unity.Mathematics;

namespace FrostbornRealms.ECS.Systems {
    public partial struct PerishableSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var cfg = ServiceLocator.Get<SimulationConfig>();
            var entity = SystemAPI.GetSingletonEntity<PerishableInventoryTag>();
            var buf = state.EntityManager.GetBuffer<PerishableStack>(entity);
            if(buf.Length==0) return;
            float ambient = cfg.AmbientTemperature;
            float tempFactor = ambient < 0 ? cfg.ColdSlowMultiplier : 1f;
            for(int i=0;i<buf.Length;i++){
                var s = buf[i];
                s.Freshness -= s.DecayPerSecond * tempFactor * SystemAPI.Time.DeltaTime;
                if(s.Freshness <= 0){
                    if(s.SpoilItemId != 0){
                        GlobalInventoryAPI.Remove(s.ItemId, s.Count);
                        GlobalInventoryAPI.Add(s.SpoilItemId, s.Count);
                    } else {
                        GlobalInventoryAPI.Remove(s.ItemId, s.Count);
                    }
                    s.Count = 0;
                }
                buf[i]=s;
            }
            // Compact removal
            for(int i=buf.Length-1;i>=0;i--){
                if(buf[i].Count<=0) buf.RemoveAt(i);
            }
        }
    }

    public static class PerishableInventoryAPI {
        static Entity entity;
        static EntityManager em;
        public static void Init(Entity e, EntityManager m){ entity=e; em=m; }
        public static void Track(int itemId, int count, float freshness, float decayPerSec, int spoilItemId){
            var buf = em.GetBuffer<PerishableStack>(entity);
            for(int i=0;i<buf.Length;i++){
                if(buf[i].ItemId==itemId){
                    var s = buf[i];
                    float total = s.Count + count;
                    s.Freshness = (s.Freshness * s.Count + freshness * count)/math.max(1,total);
                    s.Count += count;
                    buf[i]=s;
                    return;
                }
            }
            buf.Add(new PerishableStack{
                ItemId=itemId, Count=count, Freshness=freshness, DecayPerSecond=decayPerSec, SpoilItemId=spoilItemId
            });
        }
    }
}