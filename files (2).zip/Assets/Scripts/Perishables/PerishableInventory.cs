using Unity.Entities;

namespace FrostbornRealms.Perishables {
    public struct PerishableInventoryTag : IComponentData {}
    public struct PerishableStack : IBufferElementData {
        public int ItemId;
        public int Count;
        public float Freshness; // 0..100
        public float DecayPerSecond;
        public int SpoilItemId;
    }
}