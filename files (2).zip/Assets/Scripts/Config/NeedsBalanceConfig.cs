namespace FrostbornRealms.Config {
    public static class NeedsBalanceConfig {
        public const float CriticalHunger = 10f;
        public const float CriticalWarmth = 15f;
    }
}