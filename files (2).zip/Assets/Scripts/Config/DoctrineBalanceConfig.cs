namespace FrostbornRealms.Config {
    public static class DoctrineBalanceConfig {
        // Placeholder constants affecting doctrine evaluation / drift.
        public const float DriftPerDay = 0.2f;
    }
}