using Unity.Entities;
using UnityEngine;

namespace FrostbornRealms.UI {
    public partial struct EventLogBootstrapSystem : ISystem {
        public void OnCreate(ref SystemState state){
            var evt = state.EntityManager.CreateEntity(typeof(EventLogTag));
            state.EntityManager.AddBuffer<EventLogEntry>(evt);
            var threat = state.EntityManager.CreateEntity(typeof(ThreatLogTag));
            state.EntityManager.AddBuffer<ThreatLogEntry>(threat);
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){}
    }

    public static class EventLogger {
        public static void Add(World world, string line){
            var em = world.EntityManager;
            if(em.CreateEntityQuery(typeof(EventLogTag)).IsEmpty) return;
            var e = em.GetSingletonEntity<EventLogTag>();
            var buf = em.GetBuffer<EventLogEntry>(e);
            buf.Add(new EventLogEntry{ Timestamp = world.Time.ElapsedTime, Line = line });
            if(buf.Length > 256) buf.RemoveAt(0);
        }
    }
    public static class ThreatLogger {
        public static void Add(World world, string line){
            var em = world.EntityManager;
            if(em.CreateEntityQuery(typeof(ThreatLogTag)).IsEmpty) return;
            var e = em.GetSingletonEntity<ThreatLogTag>();
            var buf = em.GetBuffer<ThreatLogEntry>(e);
            buf.Add(new ThreatLogEntry{ Timestamp = world.Time.ElapsedTime, Line = line });
            if(buf.Length > 256) buf.RemoveAt(0);
        }
    }
}