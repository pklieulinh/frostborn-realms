using Unity.Entities;
using Unity.Collections;

namespace FrostbornRealms.UI {
    public struct EventLogTag : IComponentData {}
    public struct EventLogEntry : IBufferElementData {
        public double Timestamp;
        public FixedString128Bytes Line;
    }

    public struct ThreatLogTag : IComponentData {}
    public struct ThreatLogEntry : IBufferElementData {
        public double Timestamp;
        public FixedString128Bytes Line;
    }
}