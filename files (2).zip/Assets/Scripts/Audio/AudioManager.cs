using UnityEngine;
using System.Collections.Generic;
using FrostbornRealms.Assets;

namespace FrostbornRealms.Audio {
    public class AudioManager : MonoBehaviour {
        public static AudioManager Instance { get; private set; }
        AudioSource ambientSource;
        Dictionary<string, AudioClip> sfxCache = new();
        void Awake() {
            if (Instance != this && Instance != null) {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
            ambientSource = gameObject.AddComponent<AudioSource>();
            ambientSource.loop = true;
        }

        public void PlayAmbient(string key) {
            var clip = AssetResolver.Ambient(key);
            if (clip == null) return;
            if (ambientSource.clip == clip && ambientSource.isPlaying) return;
            ambientSource.clip = clip;
            ambientSource.Play();
        }

        public void PlaySFX(string key, float volume = 1f) {
            var clip = AssetResolver.SFX(key);
            if (clip == null) return;
            AudioSource.PlayClipAtPoint(clip, Vector3.zero, volume);
        }
    }
}