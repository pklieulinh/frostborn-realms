using UnityEngine;
using Unity.Entities;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.Visual {
    public class ResourceNodeGizmo : MonoBehaviour {
        World world;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }
        void OnDrawGizmos(){
            if(world==null || !world.IsCreated) return;
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(ResourceNode), typeof(Position));
            using(var ents = q.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents){
                    var node = em.GetComponentData<ResourceNode>(e);
                    var pos = em.GetComponentData<Position>(e);
                    Gizmos.color = Color.yellow;
                    Gizmos.DrawWireCube(new Vector3(pos.Value.x,pos.Value.y+0.5f,pos.Value.z), new Vector3(1,1,1));
                    UnityEditor.Handles.Label(new Vector3(pos.Value.x,pos.Value.y+1.2f,pos.Value.z), node.Remaining.ToString());
                }
            }
        }
    }
}