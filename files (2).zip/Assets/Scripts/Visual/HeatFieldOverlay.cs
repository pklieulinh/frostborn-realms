using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Heat;
using FrostbornRealms.Core;
using Unity.Mathematics;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.Visual {
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public class HeatFieldOverlay : MonoBehaviour {
        Mesh mesh;
        float timer;
        World world;
        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
            mesh = new Mesh();
            GetComponent<MeshFilter>().mesh = mesh;
            var mr = GetComponent<MeshRenderer>();
            if(mr.sharedMaterial == null){
                var mat = new Material(Shader.Find("Unlit/Color"));
                mat.color = new Color(1,0,0,0.15f);
                mr.sharedMaterial = mat;
            }
        }

        void Update(){
            if(world == null || !world.IsCreated) return;
            timer += Time.deltaTime;
            var cfg = ServiceLocator.Get<SimulationConfig>();
            if(timer < cfg.HeatFieldRebuildInterval) return;
            timer = 0;
            RebuildMesh();
        }

        void RebuildMesh(){
            var em = world.EntityManager;
            var cfg = ServiceLocator.Get<SimulationConfig>();
            int res = math.max(4, cfg.HeatFieldResolution);
            float size = 60f;
            float step = size / (res - 1);
            var verts = new Vector3[res * res];
            var colors = new Color[verts.Length];
            var tris = new int[(res-1)*(res-1)*6];
            float ambient = cfg.AmbientTemperature;
            for(int y=0;y<res;y++){
                for(int x=0;x<res;x++){
                    int idx = y*res + x;
                    float3 pos = new float3(-size*0.5f + x*step, 0, -size*0.5f + y*step);
                    verts[idx] = new Vector3(pos.x, 0.05f, pos.z);
                    float temp = SampleTemperature(pos);
                    float t = math.saturate((temp - ambient) / 60f);
                    colors[idx] = Color.Lerp(new Color(0,0,1,0.05f), new Color(1,0,0,0.35f), t);
                }
            }
            int tri = 0;
            for(int y=0;y<res-1;y++){
                for(int x=0;x<res-1;x++){
                    int a = y*res + x;
                    int b = y*res + x +1;
                    int c = (y+1)*res + x;
                    int d = (y+1)*res + x +1;
                    tris[tri++] = a; tris[tri++] = d; tris[tri++] = b;
                    tris[tri++] = a; tris[tri++] = c; tris[tri++] = d;
                }
            }
            mesh.Clear();
            mesh.vertices = verts;
            mesh.triangles = tris;
            mesh.colors = colors;
            mesh.RecalculateNormals();
        }

        float SampleTemperature(float3 position){
            var em = world.EntityManager;
            float temp = ServiceLocator.Get<SimulationConfig>().AmbientTemperature;
            foreach(var (hs, pos) in em.CreateEntityQuery(typeof(HeatSource), typeof(Position)).ToComponentDataArray<HeatSource, Position>(Unity.Collections.Allocator.Temp)){
            }
            foreach(var e in em.CreateEntityQuery(typeof(HeatSource), typeof(Position)).ToEntityArray(Unity.Collections.Allocator.Temp)){
                var hs = em.GetComponentData<HeatSource>(e);
                var p = em.GetComponentData<Position>(e);
                float dist = math.distance(position, p.Value);
                if(dist <= hs.Radius){
                    float t = 1f - dist / hs.Radius;
                    temp += hs.Intensity * t * t * 0.1f;
                }
            }
            return temp;
        }
    }
}