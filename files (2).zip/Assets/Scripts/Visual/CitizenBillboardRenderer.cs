using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Tasks;
using FrostbornRealms.ECS.Components;
using Unity.Mathematics;

namespace FrostbornRealms.Visual {
    public class CitizenBillboardRenderer : MonoBehaviour {
        World world;
        Mesh quad;
        Material matIdle;
        Material matWork;
        Camera cam;
        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
            cam = Camera.main;
            quad = BuildQuad();
            matIdle = new Material(Shader.Find("Unlit/Color")){ color = Color.cyan };
            matWork = new Material(Shader.Find("Unlit/Color")){ color = Color.yellow };
        }

        Mesh BuildQuad(){
            var m = new Mesh();
            m.vertices = new[]{
                new Vector3(-0.3f,0,0),
                new Vector3(0.3f,0,0),
                new Vector3(-0.3f,1f,0),
                new Vector3(0.3f,1f,0)
            };
            m.triangles = new[]{0,2,1,1,2,3};
            m.RecalculateNormals();
            return m;
        }

        void LateUpdate(){
            if(world == null || !world.IsCreated) return;
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(CitizenTag), typeof(Position));
            using(var ents = q.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents){
                    var pos = em.GetComponentData<Position>(e);
                    bool working = em.HasComponent<AssignedTask>(e);
                    var mat = working ? matWork : matIdle;
                    var look = cam != null ? cam.transform.rotation : Quaternion.identity;
                    var rot = look;
                    Graphics.DrawMesh(quad, Matrix4x4.TRS(new Vector3(pos.Value.x, pos.Value.y, pos.Value.z), rot, Vector3.one), mat, 0);
                }
            }
        }
    }
}