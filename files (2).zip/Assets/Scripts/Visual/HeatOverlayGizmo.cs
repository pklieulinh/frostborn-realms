using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Heat;
using FrostbornRealms.ECS.Components;
using Unity.Mathematics;

namespace FrostbornRealms.Visual {
    public class HeatOverlayGizmo : MonoBehaviour {
        World world;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }
        void OnDrawGizmos(){
            if(world == null || !world.IsCreated) return;
            var em = world.EntityManager;
            var query = em.CreateEntityQuery(typeof(HeatSource), typeof(Position));
            using(var ents = query.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents){
                    var hs = em.GetComponentData<HeatSource>(e);
                    var pos = em.GetComponentData<Position>(e);
                    float3 p = pos.Value;
                    Gizmos.color = new Color(1f,0.4f,0f,0.25f);
                    Gizmos.DrawSphere(new Vector3(p.x,p.y,p.z), hs.Radius * 0.2f);
                    Gizmos.color = new Color(1f,0.2f,0f,0.1f);
                    Gizmos.DrawWireSphere(new Vector3(p.x,p.y,p.z), hs.Radius);
                }
            }
        }
    }
}