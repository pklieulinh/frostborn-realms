using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Buildings;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.Visual {
    public class ConstructionProgressRenderer : MonoBehaviour {
        World world;
        Camera cam;
        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
            cam = Camera.main;
        }
        void OnGUI(){
            if(world==null || !world.IsCreated || cam==null) return;
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(ConstructionSite), typeof(Position));
            using(var ents = q.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents){
                    var site = em.GetComponentData<ConstructionSite>(e);
                    var pos = em.GetComponentData<Position>(e);
                    var screen = cam.WorldToScreenPoint(new Vector3(pos.Value.x, pos.Value.y, pos.Value.z));
                    if(screen.z < 0) continue;
                    float pct = Mathf.Clamp01(1f - (site.WorkRemaining / 25f));
                    var rect = new Rect(screen.x - 40, Screen.height - screen.y - 10, 80, 6);
                    GUI.backgroundColor = Color.black;
                    GUI.Box(rect, GUIContent.none);
                    var fill = new Rect(rect.x+1, rect.y+1, (rect.width-2)*pct, rect.height-2);
                    var old = GUI.color;
                    GUI.color = Color.Lerp(Color.red, Color.green, pct);
                    GUI.Box(fill, GUIContent.none);
                    GUI.color = old;
                }
            }
        }
    }
}