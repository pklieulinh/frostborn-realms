using UnityEngine;
using Unity.Entities;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.Visual {
    public class ResourceNodeBillboard : MonoBehaviour {
        World world;
        Mesh quad;
        Material matWood;
        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
            quad = new Mesh();
            quad.vertices = new[]{
                new Vector3(-0.4f,0,0),
                new Vector3(0.4f,0,0),
                new Vector3(-0.4f,0.8f,0),
                new Vector3(0.4f,0.8f,0)
            };
            quad.triangles = new[]{0,2,1,1,2,3};
            quad.RecalculateNormals();
            matWood = new Material(Shader.Find("Unlit/Color")){ color = new Color(0.6f,0.3f,0.1f,0.9f)};
        }
        void LateUpdate(){
            if(world==null || !world.IsCreated) return;
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(ResourceNode), typeof(Position));
            using(var ents = q.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents){
                    var node = em.GetComponentData<ResourceNode>(e);
                    var pos = em.GetComponentData<Position>(e);
                    var mat = matWood;
                    Graphics.DrawMesh(quad, Matrix4x4.TRS(new Vector3(pos.Value.x,pos.Value.y,pos.Value.z), Quaternion.identity, Vector3.one), mat, 0);
                }
            }
        }
    }
}