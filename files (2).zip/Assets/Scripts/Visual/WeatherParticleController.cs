using UnityEngine;
using Unity.Entities;
using FrostbornRealms.World;

namespace FrostbornRealms.Visual {
    public class WeatherParticleController : MonoBehaviour {
        World world;
        ParticleSystem snowFx;
        ParticleSystem blizzardFx;

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
            snowFx = CreateSystem("SnowFX", new Color(0.8f,0.9f,1f,0.6f), 150);
            blizzardFx = CreateSystem("BlizzardFX", new Color(0.9f,0.9f,1f,0.9f), 500);
        }

        ParticleSystem CreateSystem(string name, Color c, int rate){
            var go = new GameObject(name);
            go.transform.SetParent(transform);
            var ps = go.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.startColor = c;
            main.startSpeed = 4;
            main.startLifetime = 3;
            var emission = ps.emission;
            emission.rateOverTime = rate;
            var shape = ps.shape;
            shape.shapeType = ParticleSystemShapeType.Box;
            shape.scale = new Vector3(60,5,60);
            ps.Play();
            return ps;
        }

        void Update(){
            if(!world.IsCreated) return;
            var em = world.EntityManager;
            if(!em.CreateEntityQuery(typeof(WeatherStateTag)).IsEmpty){
                var e = em.CreateEntityQuery(typeof(WeatherStateTag)).GetSingletonEntity();
                var ws = em.GetComponentData<WeatherState>(e);
                snowFx.gameObject.SetActive(ws.Current == WeatherType.Snow);
                blizzardFx.gameObject.SetActive(ws.Current == WeatherType.Blizzard);
            }
        }
    }
}