using Unity.Entities;
using FrostbornRealms.Tasks;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.Buildings;
using FrostbornRealms.Crafting;
using FrostbornRealms.Crafting;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;

namespace FrostbornRealms.ECS.Systems {
    public partial struct TaskAssignmentSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var queueEntity = SystemAPI.GetSingletonEntity<TaskQueueTag>();
            var queue = state.EntityManager.GetBuffer<TaskRequest>(queueEntity);
            if(queue.Length == 0) return;
            foreach(var (citizen, entity) in SystemAPI.Query<RefRO<Tasks.CitizenTag>>().WithEntityAccess()){
                if(state.EntityManager.HasComponent<AssignedTask>(entity)) continue;
                if(queue.Length == 0) break;
                var req = queue[0];
                queue.RemoveAt(0);
                state.EntityManager.AddComponentData(entity, new AssignedTask{
                    Type = req.Type,
                    Target = req.TargetEntity,
                    WorkRemaining = 6f
                });
            }
        }
    }

    public partial struct CitizenWorkSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);
            foreach(var (task, entity) in SystemAPI.Query<RefRW<AssignedTask>>().WithEntityAccess()){
                var t = task.ValueRO;
                t.WorkRemaining -= SystemAPI.Time.DeltaTime;
                if(t.WorkRemaining <=0){
                    Complete(ref state, t, ecb);
                    ecb.RemoveComponent<AssignedTask>(entity);
                } else {
                    task.ValueRW = t;
                }
            }
            ecb.Playback(state.EntityManager);
        }
        static void Complete(ref SystemState state, AssignedTask t, EntityCommandBuffer ecb){
            switch(t.Type){
                case TaskType.Gather:
                    if(state.EntityManager.Exists(t.Target) && state.EntityManager.HasComponent<ResourceNode>(t.Target)){
                        var rn = state.EntityManager.GetComponentData<ResourceNode>(t.Target);
                        if(GatheringUtility.MapResource(rn.ResourceKey, out var itemId, out var perCycle)){
                            var gather = state.EntityManager.CreateEntity(typeof(ResourceSystem.GatherTask));
                            state.EntityManager.SetComponentData(gather, new ResourceSystem.GatherTask{
                                Node = t.Target,
                                WorkRemaining = 1.5f,
                                OutputItemId = itemId,
                                OutputPerCycle = perCycle
                            });
                        }
                    }
                    break;
                case TaskType.Build:
                    if(state.EntityManager.Exists(t.Target) && state.EntityManager.HasComponent<ConstructionSite>(t.Target)){
                        var site = state.EntityManager.GetComponentData<ConstructionSite>(t.Target);
                        site.WorkRemaining -= 10f;
                        state.EntityManager.SetComponentData(t.Target, site);
                    }
                    break;
                case TaskType.Craft:
                    break;
            }
        }
    }
}