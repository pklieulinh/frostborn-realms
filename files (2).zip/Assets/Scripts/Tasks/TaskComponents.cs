using Unity.Entities;

namespace FrostbornRealms.Tasks {
    public enum TaskType : byte { Gather, Build, Craft }
    public struct TaskQueueTag : IComponentData {}
    public struct TaskRequest : IBufferElementData {
        public TaskType Type;
        public int IntParam; // recipe id or building key
        public Entity TargetEntity; // node or site
    }
    public struct AssignedTask : IComponentData {
        public TaskType Type;
        public Entity Target;
        public float WorkRemaining;
    }
    public struct CitizenTag : IComponentData {}
}