using Unity.Entities;
using FrostbornRealms.Tasks;
using FrostbornRealms.Navigation;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.ECS.Systems {
    public partial struct TaskPathRequestSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var navEntity = SystemAPI.GetSingletonEntity<NavGridTag>();
            var requests = state.EntityManager.GetBuffer<PathRequest>(navEntity);
            foreach(var (assigned, pos, entity) in SystemAPI.Query<AssignedTask, RefRO<Position>>().WithEntityAccess()){
                if(state.EntityManager.HasComponent<CurrentPath>(entity)) continue;
                if(!state.EntityManager.Exists(assigned.Target)) continue;
                if(!state.EntityManager.HasComponent<Position>(assigned.Target)) continue;
                var tPos = state.EntityManager.GetComponentData<Position>(assigned.Target);
                requests.Add(new PathRequest{
                    Seeker = entity,
                    Target = tPos.Value
                });
            }
        }
    }
}