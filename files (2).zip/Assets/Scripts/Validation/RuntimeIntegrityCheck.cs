using UnityEngine;
using FrostbornRealms.Assets;

namespace FrostbornRealms {
    public class RuntimeIntegrityCheck : MonoBehaviour {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Verify() {
            if (!AssetResolver.IsInitialized) {
                Debug.LogWarning("[IntegrityCheck] AssetResolver not initialized. Invoking fallback.");
                FallbackAssetBootstrap.EnsureRuntimeFallback();
            }
        }
    }
}