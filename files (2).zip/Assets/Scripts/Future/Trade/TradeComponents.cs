using Unity.Entities;
using Unity.Collections;

namespace FrostbornRealms.Future.Trade {
    public struct TradeOfferTag : IComponentData {}
    public struct TradeOffer : IBufferElementData {
        public int OfferItemId;
        public int OfferCount;
        public int RequestItemId;
        public int RequestCount;
        public float TimeRemaining;
        public byte Accepted;
    }
    public struct TradeAcceptRequest : IComponentData {
        public int OfferIndex;
    }
}