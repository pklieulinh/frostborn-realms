using Unity.Entities;
using Unity.Collections;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;
using FrostbornRealms.Research;
using FrostbornRealms.Threats;
using FrostbornRealms.UI;

namespace FrostbornRealms.Future {
    public partial struct AchievementSystem : ISystem {
        public void OnCreate(ref SystemState state){
            if(!SystemAPI.HasSingleton<AchievementTag>()){
                var e = state.EntityManager.CreateEntity(typeof(AchievementTag));
                state.EntityManager.AddBuffer<AchievementEntry>(e);
            }
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var achEnt = SystemAPI.GetSingletonEntity<AchievementTag>();
            var buf = state.EntityManager.GetBuffer<AchievementEntry>(achEnt);
            bool changed = false;

            bool Has(int hash){
                for(int i=0;i<buf.Length;i++) if(buf[i].KeyHash==hash && buf[i].Unlocked==1) return true;
                return false;
            }
            void Unlock(string key){
                int h = key.GetHashCode();
                if(Has(h)) return;
                buf.Add(new AchievementEntry{ KeyHash = h, Unlocked = 1 });
                EventLogger.Add(state.WorldUnmanaged.World, "Achievement unlocked: " + key);
                changed = true;
            }

            // Conditions
            // FirstFirePit
            if(!Has("FirstFirePit".GetHashCode())){
                foreach(var b in SystemAPI.Query<FrostbornRealms.Buildings.Building>()){
                    if(b.KeyHash == "FirePit".GetHashCode()) Unlock("FirstFirePit");
                }
            }
            // TenPlanks
            if(!Has("TenPlanks".GetHashCode())){
                var plank = ItemRegistry.All.Find(x=>x.Name=="Plank");
                if(plank!=null && GlobalInventoryAPI.Get(plank.Id) >= 10) Unlock("TenPlanks");
            }
            // SurviveWave5
            if(!Has("SurviveWave5".GetHashCode()) && SystemAPI.HasSingleton<ThreatWaveState>()){
                var wave = SystemAPI.GetSingleton<ThreatWaveState>();
                if(wave.WaveNumber >=5) Unlock("SurviveWave5");
            }
            // FirstResearch
            if(!Has("FirstResearch".GetHashCode()) && SystemAPI.HasSingleton<ResearchStateTag>()){
                var st = SystemAPI.GetSingletonEntity<ResearchStateTag>();
                var rbuf = state.EntityManager.GetBuffer<ResearchUnlocked>(st);
                if(rbuf.Length >0) Unlock("FirstResearch");
            }
            // MarketTrade
            if(!Has("MarketTrade".GetHashCode())){
                for(int i=0;i<buf.Length;i++){
                    if(buf[i].KeyHash == "TradeMarker".GetHashCode() && buf[i].Unlocked==2){
                        Unlock("MarketTrade");
                        break;
                    }
                }
            }

            if(changed){
                // Could add persistence hook if needed
            }
        }
    }
}