using Unity.Entities;
using Unity.Mathematics;
using FrostbornRealms.Future;
using FrostbornRealms.Threats;
using FrostbornRealms.UI;

namespace FrostbornRealms.ECS.Systems {
    public partial struct TrapSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);
            foreach(var (trapRw, entity) in SystemAPI.Query<RefRW<Trap>>().WithEntityAccess()){
                var trap = trapRw.ValueRO;
                trap.TimeLeft -= SystemAPI.Time.DeltaTime;
                if(trap.TimeLeft <= 0){
                    // Trigger: damage all WolfPack threats a bit
                    foreach(var t in SystemAPI.Query<RefRW<ActiveThreat>>()){
                        if(t.ValueRO.KindHash == "WolfPack".GetHashCode()){
                            var th = t.ValueRO;
                            th.DamagePerSecond *= math.clamp(1f - trap.Damage * 0.05f, 0.1f, 1f);
                            th.TimeRemaining -= trap.Damage * 0.5f;
                            t.ValueRW = th;
                        }
                    }
                    trap.TimeLeft = trap.Cooldown;
                    ThreatLogger.Add(state.WorldUnmanaged.World, "Trap triggered");
                }
                trapRw.ValueRW = trap;
            }
            ecb.Playback(state.EntityManager);
        }
    }

    public partial struct WallIntegritySystem : ISystem {
        public void OnCreate(ref SystemState state){
            if(!SystemAPI.HasSingleton<DefenseFactorTag>()){
                state.EntityManager.CreateEntity(typeof(DefenseFactorTag));
                var e = SystemAPI.GetSingletonEntity<DefenseFactorTag>();
                state.EntityManager.SetComponentData(e, new DefenseFactorTag{ Value = 0 });
            }
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            float total = 0;
            float max = 0;
            foreach(var w in SystemAPI.Query<WallSection>()){
                total += w.Integrity;
                max += w.MaxIntegrity;
            }
            float factor = 0;
            if(max > 0) factor = math.clamp(total / max, 0, 1);
            var defEntity = SystemAPI.GetSingletonEntity<DefenseFactorTag>();
            var df = SystemAPI.GetComponent<DefenseFactorTag>(defEntity);
            df.Value = factor;
            SystemAPI.SetComponent(defEntity, df);
        }
    }

    public partial struct StructureDefenseSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            if(!SystemAPI.HasSingleton<DefenseFactorTag>()) return;
            float factor = SystemAPI.GetComponent<DefenseFactorTag>(SystemAPI.GetSingletonEntity<DefenseFactorTag>()).Value;
            if(factor <= 0) return;
            // Reduce building damage by factor
            foreach(var t in SystemAPI.Query<RefRW<ActiveThreat>>()){
                if(t.ValueRO.DamagePerSecond > 0){
                    var th = t.ValueRO;
                    th.DamagePerSecond *= math.lerp(1f, 0.3f, factor);
                    t.ValueRW = th;
                }
            }
        }
    }

    public partial struct WallDecayFromThreatSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            float wolfPressure = 0;
            foreach(var t in SystemAPI.Query<ActiveThreat>()){
                if(t.KindHash == "WolfPack".GetHashCode()){
                    wolfPressure += t.DamagePerSecond;
                }
            }
            if(wolfPressure <= 0) return;
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);
            foreach(var (wall, entity) in SystemAPI.Query<RefRW<WallSection>>().WithEntityAccess()){
                var w = wall.ValueRO;
                float decay = wolfPressure * 0.002f * SystemAPI.Time.DeltaTime;
                w.Integrity -= decay * w.MaxIntegrity;
                if(w.Integrity <= 0){
                    ecb.DestroyEntity(entity);
                } else {
                    wall.ValueRW = w;
                }
            }
            ecb.Playback(state.EntityManager);
        }
    }
}