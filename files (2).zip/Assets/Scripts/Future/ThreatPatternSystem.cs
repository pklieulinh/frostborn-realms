using Unity.Entities;
using Unity.Mathematics;
using FrostbornRealms.Threats;
using FrostbornRealms.Core;
using FrostbornRealms.UI;

namespace FrostbornRealms.Future {
    public struct ThreatScenarioTag : IComponentData {}
    public struct ThreatPatternState : IComponentData {
        public byte Phase; // 0 idle, 1 scout, 2 main, 3 aftermath
        public float PhaseTime;
        public float NextPhaseDelay;
        public int LinkedWaveNumber;
    }

    public partial struct ThreatPatternSystem : ISystem {
        public void OnCreate(ref SystemState state){
            var e = state.EntityManager.CreateEntity(typeof(ThreatScenarioTag), typeof(ThreatPatternState));
            state.EntityManager.SetComponentData(e, new ThreatPatternState{
                Phase = 0,
                PhaseTime = 0,
                NextPhaseDelay = 0,
                LinkedWaveNumber = -1
            });
        }
        public void OnDestroy(ref SystemState state){}

        public void OnUpdate(ref SystemState state){
            if(!SystemAPI.HasSingleton<ThreatWaveState>()) return;
            var cfg = ServiceLocator.Get<SimulationConfig>();
            var waveEntity = SystemAPI.GetSingletonEntity<ThreatWaveState>();
            var wave = SystemAPI.GetComponent<ThreatWaveState>(waveEntity);
            var scenarioEntity = SystemAPI.GetSingletonEntity<ThreatScenarioTag>();
            var pattern = SystemAPI.GetComponent<ThreatPatternState>(scenarioEntity);
            float dt = SystemAPI.Time.DeltaTime;
            pattern.PhaseTime += dt;

            if(pattern.Phase == 0){
                if(wave.WaveNumber > pattern.LinkedWaveNumber){
                    // Start new pattern for new wave
                    pattern.LinkedWaveNumber = wave.WaveNumber;
                    pattern.Phase = 1;
                    pattern.PhaseTime = 0;
                    pattern.NextPhaseDelay = math.clamp(5f + wave.WaveNumber * 1.5f, 5f, 25f);
                    ThreatLogger.Add(state.WorldUnmanaged.World, $"Pattern start Wave {wave.WaveNumber} phase Scout");
                    SpawnThreat(ref state, "WolfPack", 0.6f * wave.IntensityScale, 15f);
                }
            } else {
                if(pattern.PhaseTime >= pattern.NextPhaseDelay){
                    if(pattern.Phase == 1){
                        pattern.Phase = 2;
                        pattern.PhaseTime = 0;
                        pattern.NextPhaseDelay = math.clamp(20f + wave.WaveNumber * 2f, 15f, 50f);
                        ThreatLogger.Add(state.WorldUnmanaged.World, $"Pattern Wave {wave.WaveNumber} phase Main");
                        SpawnThreat(ref state, "WolfPack", 1.2f * wave.IntensityScale, 30f);
                    } else if(pattern.Phase == 2){
                        pattern.Phase = 3;
                        pattern.PhaseTime = 0;
                        pattern.NextPhaseDelay = 12f;
                        ThreatLogger.Add(state.WorldUnmanaged.World, $"Pattern Wave {wave.WaveNumber} phase Aftermath");
                        SpawnThreat(ref state, "WolfPack", 0.8f * wave.IntensityScale, 18f);
                    } else if(pattern.Phase == 3){
                        pattern.Phase = 0;
                        pattern.PhaseTime = 0;
                        pattern.NextPhaseDelay = 0;
                        ThreatLogger.Add(state.WorldUnmanaged.World, $"Pattern Wave {wave.WaveNumber} complete");
                    }
                }
            }
            SystemAPI.SetComponent(scenarioEntity, pattern);
        }

        void SpawnThreat(ref SystemState state, string kind, float intensity, float duration){
            var e = state.EntityManager.CreateEntity(typeof(ActiveThreat));
            float baseDps = kind == "WolfPack" ? 4f : 2f;
            state.EntityManager.SetComponentData(e, new ActiveThreat{
                KindHash = kind.GetHashCode(),
                TimeRemaining = duration,
                DamagePerSecond = baseDps * intensity,
                Flags = 0
            });
        }
    }
}