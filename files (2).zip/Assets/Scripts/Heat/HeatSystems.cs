using Unity.Entities;
using Unity.Mathematics;
using FrostbornRealms.Heat;
using FrostbornRealms.ECS.Components;
using FrostbornRealms.Core;
using FrostbornRealms.Doctrine;

namespace FrostbornRealms.ECS.Systems {
    public partial struct HeatGridBuildSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var gridEntity = SystemAPI.GetSingletonEntity<HeatGridTag>();
            var settings = state.EntityManager.GetComponentData<HeatGridSettings>(gridEntity);
            settings.TimeSinceRebuild += SystemAPI.Time.DeltaTime;
            if(settings.TimeSinceRebuild < settings.RebuildInterval){
                state.EntityManager.SetComponentData(gridEntity, settings);
                return;
            }
            settings.TimeSinceRebuild = 0;
            var buf = state.EntityManager.GetBuffer<HeatSourceBucket>(gridEntity);
            buf.Clear();
            float cell = settings.CellSize;
            float radiusBonus = 1f;
            foreach(var mod in SystemAPI.Query<DoctrineModifier>()){
                radiusBonus = mod.HeatRadiusBonus;
            }
            foreach(var (src, pos) in SystemAPI.Query<RefRO<HeatSource>, RefRO<Position>>()){
                int hash = HashPos(pos.ValueRO.Value, cell);
                buf.Add(new HeatSourceBucket{ CellHash = hash, Source = src.ValueRO.Intensity > 0 ? pos.Entity : Entity.Null});
            }
            state.EntityManager.SetComponentData(gridEntity, settings);
        }
        static int HashPos(float3 p, float cell){
            int x = (int)math.floor(p.x / cell);
            int z = (int)math.floor(p.z / cell);
            return (x*73856093) ^ (z*19349663);
        }
    }

    public partial struct HeatInfluenceSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var cfg = ServiceLocator.Get<SimulationConfig>();
            float ambient = cfg.AmbientTemperature;
            float dt = SystemAPI.Time.DeltaTime;
            float radiusBonus = 1f;
            foreach(var mod in SystemAPI.Query<DoctrineModifier>()){
                radiusBonus = mod.HeatRadiusBonus;
            }
            var gridEntity = SystemAPI.GetSingletonEntity<HeatGridTag>();
            var settings = state.EntityManager.GetComponentData<HeatGridSettings>(gridEntity);
            var buckets = state.EntityManager.GetBuffer<HeatSourceBucket>(gridEntity);

            foreach(var temp in SystemAPI.Query<RefRW<Temperature>>()){
                temp.ValueRW.Value = math.lerp(temp.ValueRO.Value, ambient, dt * 0.15f);
            }

            foreach(var (temp, pos) in SystemAPI.Query<RefRW<Temperature>, RefRO<Position>>()){
                float added = 0;
                Accumulate(ref added, pos.ValueRO.Value, buckets, settings.CellSize, radiusBonus, state.EntityManager);
                temp.ValueRW.Value += added * dt;
            }
        }
        static int HashPos(float3 p, float cell){
            int x = (int)math.floor(p.x / cell);
            int z = (int)math.floor(p.z / cell);
            return (x*73856093) ^ (z*19349663);
        }
        static void Accumulate(ref float added, float3 pos, DynamicBuffer<HeatSourceBucket> buckets, float cell, float radiusBonus, EntityManager em){
            int baseHash = HashPos(pos, cell);
            int2[] offsets = {
                new int2(0,0), new int2(1,0), new int2(-1,0), new int2(0,1), new int2(0,-1),
                new int2(1,1), new int2(-1,-1), new int2(1,-1), new int2(-1,1)
            };
            foreach(var off in offsets){
                int hash = CombineHash(baseHash, off);
                for(int i=0;i<buckets.Length;i++){
                    if(buckets[i].CellHash == hash && em.Exists(buckets[i].Source)){
                        if(em.HasComponent<HeatSource>(buckets[i].Source) && em.HasComponent<Position>(buckets[i].Source)){
                            var hs = em.GetComponentData<HeatSource>(buckets[i].Source);
                            var sp = em.GetComponentData<Position>(buckets[i].Source);
                            float radius = hs.Radius * radiusBonus;
                            float dist = math.distance(pos, sp.Value);
                            if(dist <= radius){
                                float t = 1f - dist / radius;
                                added += hs.Intensity * t * t;
                            }
                        }
                    }
                }
            }
        }
        static int CombineHash(int h, int2 o){
            return h ^ (o.x*83492791) ^ (o.y*15485863);
        }
    }

    public partial struct CitizenHeatAffectSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            var cfg = ServiceLocator.Get<SimulationConfig>();
            foreach(var (needs, pos) in SystemAPI.Query<RefRW<ECS.Components.Needs>, RefRO<Position>>()){
                float localTemp = cfg.AmbientTemperature;
                foreach(var (temp, tPos) in SystemAPI.Query<RefRO<Temperature>, RefRO<Position>>()){
                    float d = math.distance(pos.ValueRO.Value, tPos.ValueRO.Value);
                    if(d < 4f){
                        localTemp = math.max(localTemp, temp.ValueRO.Value);
                    }
                }
                float delta = localTemp - cfg.AmbientTemperature;
                if(delta > 0){
                    needs.ValueRW.Warmth = math.min(100, needs.ValueRW.Warmth + delta * cfg.WarmthBonusPerTempDegree * SystemAPI.Time.DeltaTime);
                }
            }
        }
    }
}