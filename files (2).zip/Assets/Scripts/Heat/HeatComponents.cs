using Unity.Entities;

namespace FrostbornRealms.Heat {
    public struct HeatSource : IComponentData {
        public float Intensity;
        public float Radius;
    }
    public struct Temperature : IComponentData {
        public float Value;
    }
    public struct HeatGridTag : IComponentData {}
    public struct HeatGridSettings : IComponentData {
        public float CellSize;
        public float RebuildInterval;
        public float TimeSinceRebuild;
    }
    public struct HeatSourceBucket : IBufferElementData {
        public int CellHash;
        public Entity Source;
    }
}