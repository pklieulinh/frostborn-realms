using Unity.Entities;
using FrostbornRealms.Data;
using System.Collections.Generic;
using UnityEngine;

namespace FrostbornRealms.Inventory {
    public struct GlobalInventoryTag : IComponentData {}
    public struct InventoryItemSlot : IBufferElementData {
        public int ItemId;
        public int Count;
    }
    public struct CategoryAggregate : IComponentData {
        public int Fuel;
        public int Food;
        public int Medicine;
    }
    public static class GlobalInventoryAPI {
        static Entity entity;
        static EntityManager em;
        static bool initialized;
        static Dictionary<int,int> cache = new();
        public static void Init(Entity e, EntityManager m){
            entity = e; em = m; initialized = true; RebuildCache();
        }
        static void RebuildCache(){
            cache.Clear();
            var buf = em.GetBuffer<InventoryItemSlot>(entity);
            for(int i=0;i<buf.Length;i++) cache[buf[i].ItemId] = buf[i].Count;
        }
        static void SyncBuffer(){
            var buf = em.GetBuffer<InventoryItemSlot>(entity);
            buf.Clear();
            foreach(var kv in cache) if(kv.Value>0) buf.Add(new InventoryItemSlot{ ItemId=kv.Key, Count=kv.Value});
        }
        public static void Add(int itemId, int count){
            if(!initialized) return;
            if(!cache.ContainsKey(itemId)) cache[itemId]=0;
            cache[itemId]+=count;
            SyncBuffer();
            UpdateCategory(itemId, count);
        }
        public static bool Remove(int itemId, int count){
            if(!initialized) return false;
            if(!cache.TryGetValue(itemId, out var have) || have<count) return false;
            have -= count;
            if(have<=0) cache.Remove(itemId); else cache[itemId]=have;
            SyncBuffer();
            UpdateCategory(itemId, -count);
            return true;
        }
        public static int Get(int itemId)=> cache.TryGetValue(itemId, out var v)?v:0;
        static void UpdateCategory(int itemId, int delta){
            var def = ItemRegistry.All.Find(x=>x.Id==itemId);
            if(def==null) return;
            var catAgg = em.GetComponentData<CategoryAggregate>(entity);
            switch(def.Category){
                case "fuel": catAgg.Fuel += delta; break;
                case "food": catAgg.Food += delta; break;
                case "medicine": catAgg.Medicine += delta; break;
            }
            em.SetComponentData(entity, catAgg);
        }
        public static void AdjustCategory(int categoryKey, int delta){
            var catAgg = em.GetComponentData<CategoryAggregate>(entity);
            if("fuel".GetHashCode()==categoryKey) catAgg.Fuel += delta;
            else if("food".GetHashCode()==categoryKey) catAgg.Food += delta;
            else if("medicine".GetHashCode()==categoryKey) catAgg.Medicine += delta;
            em.SetComponentData(entity, catAgg);
        }
        public static Dictionary<int,int> Snapshot() => new(cache);
        public static void LoadSnapshot(Dictionary<int,int> snap){
            cache = snap ?? new Dictionary<int,int>();
            SyncBuffer();
            var catAgg = new CategoryAggregate();
            foreach(var kv in cache){
                var def = ItemRegistry.All.Find(x=>x.Id==kv.Key);
                if(def==null) continue;
                switch(def.Category){
                    case "fuel": catAgg.Fuel += kv.Value; break;
                    case "food": catAgg.Food += kv.Value; break;
                    case "medicine": catAgg.Medicine += kv.Value; break;
                }
            }
            em.SetComponentData(entity, catAgg);
        }
        public static IEnumerable<KeyValuePair<int,int>> Enumerate() => cache;
    }
}