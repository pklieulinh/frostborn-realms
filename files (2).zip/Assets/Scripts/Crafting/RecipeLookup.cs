using System.Collections.Generic;
using FrostbornRealms.Data;

namespace FrostbornRealms.Crafting {
    public static class RecipeLookup {
        static Dictionary<int,RecipeDef> idCache;
        static Dictionary<string,RecipeDef> keyCache;
        static bool built;
        public static void Build(){
            if(built) return;
            idCache = new();
            keyCache = new(System.StringComparer.OrdinalIgnoreCase);
            foreach(var r in RecipeRegistry.All){
                idCache[r.Id]=r;
                keyCache[r.Key]=r;
            }
            built = true;
        }
        public static bool TryGet(int id, out RecipeDef def){
            Build();
            return idCache.TryGetValue(id, out def);
        }
        public static bool TryGetKey(string key, out RecipeDef def){
            Build();
            return keyCache.TryGetValue(key, out def);
        }
    }
}