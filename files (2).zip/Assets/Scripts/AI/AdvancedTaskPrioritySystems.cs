using Unity.Entities;
using FrostbornRealms.Tasks;
using FrostbornRealms.AI;
using FrostbornRealms.Inventory;
using FrostbornRealms.Core;
using FrostbornRealms.ECS.Components;
using Unity.Mathematics;

namespace FrostbornRealms.ECS.Systems {
    public partial struct UtilityAIGoalScoringSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            var cfg = ServiceLocator.Get<SimulationConfig>();
            var queueEntity = SystemAPI.GetSingletonEntity<TaskQueueTag>();
            var queue = state.EntityManager.GetBuffer<TaskRequest>(queueEntity);
            int pendingGather = 0;
            foreach(var t in queue){
                if(t.Type == TaskType.Gather) pendingGather++;
            }
            foreach(var (citizen, needs, entity) in SystemAPI.Query<CitizenTag, RefRO<Needs>>().WithEntityAccess()){
                float hungerDef = math.max(0, 70 - needs.ValueRO.Hunger)/70f;
                float warmthDef = math.max(0, 60 - needs.ValueRO.Warmth)/60f;
                float moraleDef = math.max(0, 65 - needs.ValueRO.Morale)/65f;
                float gatherWeight = hungerDef * 0.6f + warmthDef * 0.2f + moraleDef * 0.2f;
                float buildWeight = 0.2f + moraleDef * 0.3f;
                float craftWeight = 0.15f + hungerDef * 0.1f;
                float idleWeight = 0.05f;
                if(pendingGather > 5) gatherWeight *= 0.5f;
                var best = AIGoal.Gather;
                float bestScore = gatherWeight;
                if(buildWeight > bestScore){ bestScore=buildWeight; best=AIGoal.Build; }
                if(craftWeight > bestScore){ bestScore=craftWeight; best=AIGoal.Craft; }
                if(idleWeight > bestScore){ bestScore=idleWeight; best=AIGoal.Idle; }

                if(best == AIGoal.Gather){
                    // leave enqueue to CitizenAISystem already handling heuristics
                } else if(best == AIGoal.Build){
                    // rely on existing system adding build tasks if site exists
                } else if(best == AIGoal.Craft){
                    // future: add craft job request buffer
                }
            }
        }
    }
}