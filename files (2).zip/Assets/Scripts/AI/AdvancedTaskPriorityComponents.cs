using Unity.Entities;

namespace FrostbornRealms.AI {
    public struct TaskPriorityRequestTag : IComponentData {}
    public enum AIGoal : byte { Gather, Build, Craft, Idle }
    public struct AIGoalScore : IBufferElementData {
        public AIGoal Goal;
        public float Score;
    }
}