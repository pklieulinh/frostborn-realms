using Unity.Entities;
using System.Collections.Generic;

namespace FrostbornRealms.Doctrine {
    public struct DoctrineProgressTag : IComponentData {}
    public struct DoctrineProgressEntry : IBufferElementData {
        public int KeyHash;
        public float Progress;
    }
    public struct DoctrineModifier : IComponentData {
        public float MoraleDecayMultiplier;
        public float HeatRadiusBonus;
        public float CraftSpeedBonus;
    }
    public static class DoctrineProgressAPI {
        static Entity entity;
        static EntityManager em;
        static bool init;
        public static void Init(Entity e, EntityManager m){ entity=e; em=m; init=true; }
        public static void AddProgress(int hash, float amt){
            if(!init) return;
            var buf = em.GetBuffer<DoctrineProgressEntry>(entity);
            for(int i=0;i<buf.Length;i++){
                if(buf[i].KeyHash==hash){
                    var e = buf[i]; e.Progress += amt; buf[i]=e; return;
                }
            }
            buf.Add(new DoctrineProgressEntry{ KeyHash=hash, Progress=amt});
        }
        public static Dictionary<int,float> Snapshot(){
            var buf = em.GetBuffer<DoctrineProgressEntry>(entity);
            var d = new Dictionary<int,float>(buf.Length);
            for(int i=0;i<buf.Length;i++) d[buf[i].KeyHash]=buf[i].Progress;
            return d;
        }
        public static void Load(Dictionary<int,float> snap){
            var buf = em.GetBuffer<DoctrineProgressEntry>(entity);
            buf.Clear();
            if(snap!=null) foreach(var kv in snap) buf.Add(new DoctrineProgressEntry{ KeyHash=kv.Key, Progress=kv.Value});
        }
    }
}