using Unity.Entities;
using FrostbornRealms.Doctrine;
using FrostbornRealms.Core;

namespace FrostbornRealms.ECS.Systems {
    public partial struct DoctrineModifiersSystem : ISystem {
        public void OnCreate(ref SystemState state) {
            var entity = state.EntityManager.CreateEntity(typeof(DoctrineModifier));
            state.EntityManager.SetComponentData(entity, new DoctrineModifier{
                MoraleDecayMultiplier = 1f,
                HeatRadiusBonus = 1f,
                CraftSpeedBonus = 1f
            });
        }
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var cfg = ServiceLocator.Get<SimulationConfig>();
            var progressEntity = SystemAPI.GetSingletonEntity<DoctrineProgressTag>();
            var buf = state.EntityManager.GetBuffer<DoctrineProgressEntry>(progressEntity);
            float moraleMult = 1f;
            float heatBonus = 1f;
            float craftBonus = 1f;
            for(int i=0;i<buf.Length;i++){
                var p = buf[i];
                if(p.KeyHash == "Stoicism".GetHashCode() && p.Progress >= 100f){
                    moraleMult *= cfg.StoicismMoraleDecayMultiplier;
                }
                if(p.KeyHash == "FurnaceMastery".GetHashCode() && p.Progress >= 120f){
                    heatBonus *= cfg.FurnaceRadiusBonus;
                }
                if(p.KeyHash == "Logistics".GetHashCode() && p.Progress >= 90f){
                    craftBonus *= cfg.CraftSpeedBonus;
                }
            }
            foreach(var mod in SystemAPI.Query<RefRW<DoctrineModifier>>()){
                mod.ValueRW = new DoctrineModifier{
                    MoraleDecayMultiplier = moraleMult,
                    HeatRadiusBonus = heatBonus,
                    CraftSpeedBonus = craftBonus
                };
            }
        }
    }
}