using Unity.Entities;
using FrostbornRealms.Telemetry;
using FrostbornRealms.Core;
using FrostbornRealms.Balancing;
using Unity.Mathematics;

namespace FrostbornRealms.ECS.Systems {
    public partial struct EconomyBalancerSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            if(!SystemAPI.HasSingleton<TelemetryBufferTag>()) return;
            if(!SystemAPI.HasSingleton<EconomyTuning>()) return;

            var cfg = ServiceLocator.Get<SimulationConfig>();
            var telEntity = SystemAPI.GetSingletonEntity<TelemetryBufferTag>();
            var runtime = state.EntityManager.GetComponentData<TelemetryRuntime>(telEntity);
            var tuningEntity = SystemAPI.GetSingletonEntity<EconomyTuning>();
            var tuning = state.EntityManager.GetComponentData<EconomyTuning>(tuningEntity);

            float hunger = runtime.RollingHungerAvg;
            float warmth = runtime.RollingWarmthAvg;
            float morale = runtime.RollingMoraleAvg;

            EconomyTuning target = tuning;

            if(hunger > cfg.TargetAvgHunger + 10f){
                target.NeedsDecayMultiplier = math.max(cfg.MinNeedsDecayMultiplier, tuning.NeedsDecayMultiplier * 0.96f);
            } else if(hunger < cfg.TargetAvgHunger - 10f){
                target.NeedsDecayMultiplier = math.min(cfg.MaxNeedsDecayMultiplier, tuning.NeedsDecayMultiplier * 1.02f);
            }

            if(warmth < cfg.TargetAvgWarmth - 12f){
                target.ResourceYieldMultiplier = math.min(cfg.MaxResourceYieldMultiplier, tuning.ResourceYieldMultiplier * 1.01f);
            }

            if(morale < cfg.TargetAvgMorale - 10f){
                target.ThreatFrequencyMultiplier = math.max(cfg.MinThreatFreqMultiplier, tuning.ThreatFrequencyMultiplier * 0.95f);
            } else if(morale > cfg.TargetAvgMorale + 15f){
                target.ThreatFrequencyMultiplier = math.min(cfg.MaxThreatFreqMultiplier, tuning.ThreatFrequencyMultiplier * 1.03f);
            }

            float t = 0.1f;
            tuning.LerpTowards(target, t);
            tuning.NeedsDecayMultiplier = math.clamp(tuning.NeedsDecayMultiplier, cfg.MinNeedsDecayMultiplier, cfg.MaxNeedsDecayMultiplier);
            tuning.CraftSpeedMultiplier = math.clamp(tuning.CraftSpeedMultiplier, cfg.MinCraftSpeedMultiplier, cfg.MaxCraftSpeedMultiplier);
            tuning.ResourceYieldMultiplier = math.clamp(tuning.ResourceYieldMultiplier, cfg.MinResourceYieldMultiplier, cfg.MaxResourceYieldMultiplier);
            tuning.ThreatFrequencyMultiplier = math.clamp(tuning.ThreatFrequencyMultiplier, cfg.MinThreatFreqMultiplier, cfg.MaxThreatFreqMultiplier);

            state.EntityManager.SetComponentData(tuningEntity, tuning);
        }
    }
}