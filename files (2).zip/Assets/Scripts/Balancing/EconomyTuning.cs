using Unity.Entities;
using Unity.Mathematics;

namespace FrostbornRealms.Balancing {
    public struct EconomyTuning : IComponentData {
        public float NeedsDecayMultiplier;
        public float CraftSpeedMultiplier;
        public float ResourceYieldMultiplier;
        public float ThreatFrequencyMultiplier;
        public static EconomyTuning Default(){
            return new EconomyTuning{
                NeedsDecayMultiplier = 1f,
                CraftSpeedMultiplier = 1f,
                ResourceYieldMultiplier = 1f,
                ThreatFrequencyMultiplier = 1f
            };
        }
        public void LerpTowards(in EconomyTuning target, float t){
            NeedsDecayMultiplier = math.lerp(NeedsDecayMultiplier, target.NeedsDecayMultiplier, t);
            CraftSpeedMultiplier = math.lerp(CraftSpeedMultiplier, target.CraftSpeedMultiplier, t);
            ResourceYieldMultiplier = math.lerp(ResourceYieldMultiplier, target.ResourceYieldMultiplier, t);
            ThreatFrequencyMultiplier = math.lerp(ThreatFrequencyMultiplier, target.ThreatFrequencyMultiplier, t);
        }
    }
}