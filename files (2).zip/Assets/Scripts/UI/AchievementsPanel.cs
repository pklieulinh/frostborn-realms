using UnityEngine;
using UnityEngine.UI;
using Unity.Entities;
using FrostbornRealms.Future;
using System.Text;

namespace FrostbornRealms.UI {
    public class AchievementsPanel : MonoBehaviour {
        [SerializeField] GameObject body;
        [SerializeField] Button toggleButton;
        [SerializeField] Text listText;
        [SerializeField] float refreshInterval = 2f;
        float timer;
        World world;

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
        }

        void Start(){
            if(toggleButton) toggleButton.onClick.AddListener(()=> body.SetActive(!body.activeSelf));
        }

        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            var em = world.EntityManager;
            if(em.CreateEntityQuery(typeof(AchievementTag)).IsEmpty) return;
            var achEnt = em.GetSingletonEntity<AchievementTag>();
            var buf = em.GetBuffer<AchievementEntry>(achEnt);
            var sb = new StringBuilder();
            foreach(var e in buf){
                if(e.Unlocked == 1){
                    sb.AppendLine(HashToName(e.KeyHash));
                }
            }
            if(listText) listText.text = sb.ToString();
        }

        string HashToName(int h){
            if(h == "FirstFirePit".GetHashCode()) return "FirstFirePit";
            if(h == "TenPlanks".GetHashCode()) return "TenPlanks";
            if(h == "SurviveWave5".GetHashCode()) return "SurviveWave5";
            if(h == "FirstResearch".GetHashCode()) return "FirstResearch";
            if(h == "MarketTrade".GetHashCode()) return "MarketTrade";
            return h.ToString();
        }
    }
}