using UnityEngine;
using UnityEngine.UI;
using Unity.Entities;
using System.Text;

namespace FrostbornRealms.UI {
    public class EventLogPanel : MonoBehaviour {
        [SerializeField] Text logText;
        [SerializeField] int maxLines = 30;
        [SerializeField] float refreshInterval = 0.75f;
        float timer;
        World world;

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
        }

        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            if(!world.IsCreated) return;
            if(!world.EntityManager.CreateEntityQuery(typeof(EventLogTag)).IsEmpty){
                var e = world.EntityManager.GetSingletonEntity<EventLogTag>();
                var buf = world.EntityManager.GetBuffer<EventLogEntry>(e);
                var sb = new StringBuilder();
                int start = Mathf.Max(0, buf.Length - maxLines);
                for(int i=start;i<buf.Length;i++){
                    sb.Append(buf[i].Timestamp.ToString("F0")).Append(": ").Append(buf[i].Line.ToString()).Append('\n');
                }
                if(logText) logText.text = sb.ToString();
            }
        }
    }
}