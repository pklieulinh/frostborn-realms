using UnityEngine;
using UnityEngine.UI;
using Unity.Entities;
using FrostbornRealms.Research;
using System.Text;

namespace FrostbornRealms.UI {
    public class ResearchPanel : MonoBehaviour {
        [SerializeField] GameObject body;
        [SerializeField] Button toggleButton;
        [SerializeField] RectTransform listRoot;
        [SerializeField] GameObject buttonPrefab;
        [SerializeField] Text pointsLabel;
        [SerializeField] float refreshInterval = 1f;
        float timer;
        World world;

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
        }

        void Start(){
            if(toggleButton) toggleButton.onClick.AddListener(()=> body.SetActive(!body.activeSelf));
            Rebuild();
        }

        void Rebuild(){
            if(listRoot == null || buttonPrefab == null) return;
            foreach(Transform c in listRoot) Destroy(c.gameObject);
            var em = world.EntityManager;
            Entity stateEnt = Entity.Null;
            if(!em.CreateEntityQuery(typeof(ResearchStateTag)).IsEmpty)
                stateEnt = em.GetSingletonEntity<ResearchStateTag>();
            foreach(var node in ResearchGraphAPI.AllNodes()){
                var go = Instantiate(buttonPrefab, listRoot);
                go.name = "Research_" + node.Key;
                var txt = go.GetComponentInChildren<Text>();
                bool unlocked = stateEnt != Entity.Null && ResearchRuntime.IsUnlocked(em, stateEnt, node.Key);
                var sb = new StringBuilder();
                sb.Append(node.Key).Append(" (").Append(node.Cost).Append(")");
                if(unlocked) sb.Append(" [Unlocked]");
                txt.text = sb.ToString();
                var btn = go.GetComponent<Button>();
                btn.interactable = !unlocked;
                string localKey = node.Key;
                btn.onClick.AddListener(()=> RequestUnlock(localKey));
            }
        }

        void RequestUnlock(string key){
            var em = world.EntityManager;
            var e = em.CreateEntity(typeof(ResearchUnlockRequest));
            em.SetComponentData(e, new ResearchUnlockRequest{ KeyHash = key.GetHashCode() });
        }

        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            var em = world.EntityManager;
            if(pointsLabel != null && !em.CreateEntityQuery(typeof(ResearchPointsTag)).IsEmpty){
                var rp = em.GetComponentData<ResearchPointsTag>(em.GetSingletonEntity<ResearchPointsTag>());
                pointsLabel.text = $"Research Points: {rp.Points:F1}";
            }
            Rebuild(); // simple refresh (could optimize diff)
        }
    }
}