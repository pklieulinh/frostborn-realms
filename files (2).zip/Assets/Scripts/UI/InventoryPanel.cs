using UnityEngine;
using UnityEngine.UI;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;
using System.Text;

namespace FrostbornRealms.UI {
    public class InventoryPanel : MonoBehaviour {
        [SerializeField] Button toggleButton;
        [SerializeField] GameObject panelBody;
        [SerializeField] Text content;
        [SerializeField] float refreshInterval = 0.5f;
        float timer;

        void Start(){
            if(toggleButton != null)
                toggleButton.onClick.AddListener(()=> panelBody.SetActive(!panelBody.activeSelf));
            if(panelBody != null) panelBody.SetActive(true);
        }

        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            if(content == null) return;
            var sb = new StringBuilder();
            foreach(var kv in GlobalInventoryAPI.Enumerate()){
                var def = ItemRegistry.All.Find(x=>x.Id==kv.Key);
                sb.Append(def?.Name ?? kv.Key.ToString()).Append(": ").Append(kv.Value).Append('\n');
            }
            content.text = sb.ToString();
        }
    }
}