using UnityEngine;
using Unity.Entities;
using FrostbornRealms.ECS.Components;
using FrostbornRealms.Inventory;
using FrostbornRealms.Doctrine;
using FrostbornRealms.World;
using FrostbornRealms.Telemetry;
using FrostbornRealms.Balancing;
using FrostbornRealms.Threats;
using FrostbornRealms.Navigation;

namespace FrostbornRealms.UI {
    public class DebugHUD : MonoBehaviour {
        bool visible = true;
        Rect rect = new Rect(10,10,560,380);
        World world;
        Vector2 scroll;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }
        void Update(){
            if(Input.GetKeyDown(KeyCode.F3)) visible = !visible;
            if(Input.GetKeyDown(KeyCode.F5)) SaveLoad.SaveLoadService.Save(world);
            if(Input.GetKeyDown(KeyCode.F9)) SaveLoad.SaveLoadService.Load(world);
        }
        void OnGUI(){
            if(!visible) return;
            GUILayout.BeginArea(rect, GUI.skin.box);
            scroll = GUILayout.BeginScrollView(scroll, GUILayout.Width(rect.width-10), GUILayout.Height(rect.height-20));
            GUILayout.Label("DEBUG HUD");
            var em = world.EntityManager;

            var needsQuery = em.CreateEntityQuery(typeof(Needs));
            using(var arr = needsQuery.ToComponentDataArray<Needs>(Unity.Collections.Allocator.Temp)){
                if(arr.Length>0){
                    float h=0,w=0,m=0,f=0;
                    foreach(var n in arr){ h+=n.Hunger; w+=n.Warmth; m+=n.Morale; f+=n.Fatigue; }
                    float inv = 1f/arr.Length;
                    GUILayout.Label($"Needs Avg H:{h*inv:F1} W:{w*inv:F1} M:{m*inv:F1} F:{f*inv:F1}");
                } else GUILayout.Label("No Citizens");
            }
            if(em.TryGetComponent<TimeOfDay>(SystemAPI.GetSingletonEntity<TimeOfDayTag>(), out var tod)){
                GUILayout.Label($"TimeOfDay: {tod.CurrentSeconds:F1}s");
            }
            if(em.TryGetComponent<WeatherState>(SystemAPI.GetSingletonEntity<WeatherStateTag>(), out var ws)){
                GUILayout.Label($"Weather: {ws.Current} ({ws.TimeRemaining:F0}s)");
            }
            if(SystemAPI.HasSingleton<DoctrineModifier>()){
                var mod = em.GetComponentData<DoctrineModifier>(SystemAPI.GetSingletonEntity<DoctrineModifier>());
                GUILayout.Label($"Doctrine Mods MoraleDecay x{mod.MoraleDecayMultiplier:F2} Heat x{mod.HeatRadiusBonus:F2} Craft x{mod.CraftSpeedBonus:F2}");
            }
            if(SystemAPI.HasSingleton<EconomyTuning>()){
                var ec = em.GetComponentData<EconomyTuning>(SystemAPI.GetSingletonEntity<EconomyTuning>());
                GUILayout.Label($"Economy: NeedsDecay x{ec.NeedsDecayMultiplier:F2} Craft x{ec.CraftSpeedMultiplier:F2} Yield x{ec.ResourceYieldMultiplier:F2} ThreatFreq x{ec.ThreatFrequencyMultiplier:F2}");
                if(GUILayout.Button("Reset Economy")){
                    ec = EconomyTuning.Default();
                    em.SetComponentData(SystemAPI.GetSingletonEntity<EconomyTuning>(), ec);
                }
            }
            if(SystemAPI.HasSingleton<TelemetryBufferTag>()){
                var runtime = em.GetComponentData<TelemetryRuntime>(SystemAPI.GetSingletonEntity<TelemetryBufferTag>());
                GUILayout.Label($"Telemetry Avg: H:{runtime.RollingHungerAvg:F1} W:{runtime.RollingWarmthAvg:F1} M:{runtime.RollingMoraleAvg:F1}");
                GUILayout.Label($"Telemetry Std: H:{runtime.RollingHungerStd:F1} W:{runtime.RollingWarmthStd:F1} M:{runtime.RollingMoraleStd:F1}");
            }
            if(SystemAPI.HasSingleton<ThreatWaveState>()){
                var wave = em.GetComponentData<ThreatWaveState>(SystemAPI.GetSingletonEntity<ThreatWaveState>());
                GUILayout.Label($"Wave: {wave.WaveNumber} NextTimer:{wave.TimeSinceLastWave:F1} Scale:{wave.IntensityScale:F2}");
            }
            int activeThreats = 0;
            foreach(var _ in SystemAPI.Query<ActiveThreat>()) activeThreats++;
            GUILayout.Label($"Active Threats: {activeThreats}");
            if(SystemAPI.HasSingleton<NavGridTag>()){
                var cfg = em.GetComponentData<FrostbornRealms.Navigation.NavGridConfig>(SystemAPI.GetSingletonEntity<NavGridTag>());
                GUILayout.Label($"NavGrid {cfg.Width}x{cfg.Height} Cell:{cfg.CellSize:F2}");
            }
            GUILayout.Label("[F5] Save  [F9] Load  [F3] Toggle");
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }
    }
}