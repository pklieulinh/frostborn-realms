using UnityEngine;
using Unity.Entities;

namespace FrostbornRealms.UI {
    public class UIManager : MonoBehaviour {
        [SerializeField] Canvas rootCanvas;
        [SerializeField] InventoryPanel inventoryPanelPrefab;
        [SerializeField] CraftingPanel craftingPanelPrefab;
        [SerializeField] StatsPanel statsPanelPrefab;
        [SerializeField] EventLogPanel eventLogPanelPrefab;
        [SerializeField] ThreatLogPanel threatLogPanelPrefab;
        [SerializeField] ResearchPanel researchPanelPrefab;
        [SerializeField] TopBarPanel topBarPanelPrefab;

        void Awake(){
            if(rootCanvas == null){
                var go = new GameObject("GameCanvas");
                rootCanvas = go.AddComponent<Canvas>();
                rootCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                go.AddComponent<CanvasScaler>();
                go.AddComponent<GraphicRaycaster>();
            }
            Ensure(inventoryPanelPrefab);
            Ensure(craftingPanelPrefab);
            Ensure(statsPanelPrefab);
            Ensure(eventLogPanelPrefab);
            Ensure(threatLogPanelPrefab);
            Ensure(researchPanelPrefab);
            Ensure(topBarPanelPrefab);
        }

        void Ensure<T>(T prefab) where T: Component {
            if(prefab == null) return;
            var existing = FindObjectOfType<T>();
            if(existing != null) return;
            var inst = Instantiate(prefab, rootCanvas.transform);
            inst.gameObject.name = typeof(T).Name;
        }
    }
}