using System;
using UnityEngine;

namespace FrostbornRealms.UI.Binding {
    [Serializable]
    public class UINotifyValue<T> {
        public event Action<T> OnChanged;
        [SerializeField] T value;
        public T Value {
            get => value;
            set {
                if(!Equals(this.value, value)){
                    this.value = value;
                    OnChanged?.Invoke(value);
                }
            }
        }
    }
}