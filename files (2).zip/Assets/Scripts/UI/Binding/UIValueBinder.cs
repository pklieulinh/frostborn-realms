using UnityEngine;
using UnityEngine.UI;

namespace FrostbornRealms.UI.Binding {
    public class UIValueBinder : MonoBehaviour {
        [SerializeField] Text targetText;
        public void Bind(UINotifyValue<string> val){
            if(targetText == null) targetText = GetComponent<Text>();
            val.OnChanged += v => {
                if(targetText != null) targetText.text = v;
            };
        }
    }
}