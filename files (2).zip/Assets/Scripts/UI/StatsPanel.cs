using UnityEngine;
using UnityEngine.UI;
using Unity.Entities;
using FrostbornRealms.ECS.Components;
using FrostbornRealms.Telemetry;

namespace FrostbornRealms.UI {
    public class StatsPanel : MonoBehaviour {
        [SerializeField] Text needsLine;
        [SerializeField] Text telemetryLine;
        [SerializeField] float refreshInterval = 0.5f;
        float timer;
        World world;

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
        }

        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(Needs));
            float h=0,w=0,m=0,f=0;
            int count=0;
            using(var arr = q.ToComponentDataArray<Needs>(Unity.Collections.Allocator.Temp)){
                foreach(var n in arr){ h+=n.Hunger; w+=n.Warmth; m+=n.Morale; f+=n.Fatigue; count++; }
            }
            if(count>0){
                float inv = 1f/count;
                if(needsLine) needsLine.text = $"Needs Avg H:{h*inv:F1} W:{w*inv:F1} M:{m*inv:F1} F:{f*inv:F1}";
            }
            if(telemetryLine && world.EntityManager.Exists(world.EntityManager.CreateEntityQuery(typeof(TelemetryBufferTag)).GetSingletonEntity())){
                var telE = world.EntityManager.GetSingletonEntity<TelemetryBufferTag>();
                var runtime = em.GetComponentData<TelemetryRuntime>(telE);
                telemetryLine.text = $"Telemetry H:{runtime.RollingHungerAvg:F1} W:{runtime.RollingWarmthAvg:F1} M:{runtime.RollingMoraleAvg:F1}";
            }
        }
    }
}