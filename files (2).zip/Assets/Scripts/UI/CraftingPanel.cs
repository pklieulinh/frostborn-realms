using UnityEngine;
using UnityEngine.UI;
using FrostbornRealms.Data;
using FrostbornRealms.Inventory;
using FrostbornRealms.Crafting;
using Unity.Entities;

namespace FrostbornRealms.UI {
    public class CraftingPanel : MonoBehaviour {
        [SerializeField] RectTransform listRoot;
        [SerializeField] Button toggleButton;
        [SerializeField] GameObject body;
        [SerializeField] GameObject recipeButtonPrefab;
        World world;

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
        }

        void Start(){
            if(toggleButton) toggleButton.onClick.AddListener(()=> body.SetActive(!body.activeSelf));
            Rebuild();
        }

        void Rebuild(){
            foreach(Transform c in listRoot) Destroy(c.gameObject);
            foreach(var r in RecipeRegistry.All){
                var go = Instantiate(recipeButtonPrefab, listRoot);
                go.name = "Recipe_" + r.Key;
                var txt = go.GetComponentInChildren<Text>();
                if(txt) txt.text = r.Key;
                var btn = go.GetComponent<Button>();
                btn.onClick.AddListener(()=> TryCraft(r.Id));
            }
        }

        void TryCraft(int recipeId){
            if(!RecipeLookup.TryGet(recipeId, out var def)) return;
            foreach(var inp in def.Inputs){
                var item = ItemRegistry.All.Find(x=>x.Name==inp.Item);
                if(item == null || GlobalInventoryAPI.Get(item.Id) < inp.Count) return;
            }
            foreach(var inp in def.Inputs){
                var item = ItemRegistry.All.Find(x=>x.Name==inp.Item);
                GlobalInventoryAPI.Remove(item.Id, inp.Count);
            }
            var em = world.EntityManager;
            var e = em.CreateEntity(typeof(CraftOrder));
            em.SetComponentData(e, new CraftOrder{ RecipeId=recipeId, TimeRemaining = def.CraftTime });
        }
    }
}