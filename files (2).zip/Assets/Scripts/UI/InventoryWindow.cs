using UnityEngine;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;

namespace FrostbornRealms.UI {
    public class InventoryWindow : MonoBehaviour {
        Rect rect = new Rect(500,10,300,400);
        bool open = true;
        void Update(){
            if(Input.GetKeyDown(KeyCode.I)) open = !open;
        }
        void OnGUI(){
            if(!open) return;
            GUILayout.BeginArea(rect, GUI.skin.window);
            GUILayout.Label("Inventory");
            foreach(var kv in GlobalInventoryAPI.Enumerate()){
                var def = ItemRegistry.All.Find(x=>x.Id==kv.Key);
                GUILayout.Label($"{def?.Name ?? kv.Key.ToString()}: {kv.Value}");
            }
            GUILayout.EndArea();
        }
    }
}