using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Crafting;
using FrostbornRealms.Data;
using FrostbornRealms.Inventory;

namespace FrostbornRealms.UI {
    public class CraftingWindow : MonoBehaviour {
        Rect rect = new Rect(810,10,300,400);
        bool open = true;
        Vector2 scroll;
        World world;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }
        void Update(){
            if(Input.GetKeyDown(KeyCode.C)) open = !open;
        }
        void OnGUI(){
            if(!open) return;
            GUILayout.BeginArea(rect, GUI.skin.window);
            GUILayout.Label("Crafting");
            scroll = GUILayout.BeginScrollView(scroll);
            foreach(var r in RecipeRegistry.All){
                bool can = true;
                foreach(var inp in r.Inputs){
                    var def = ItemRegistry.All.Find(x=>x.Name==inp.Item);
                    if(def==null || GlobalInventoryAPI.Get(def.Id) < inp.Count){
                        can=false; break;
                    }
                }
                GUILayout.BeginHorizontal();
                GUILayout.Label(r.Key, GUILayout.Width(130));
                GUI.enabled = can;
                if(GUILayout.Button("Craft", GUILayout.Width(60))){
                    foreach(var inp in r.Inputs){
                        var def = ItemRegistry.All.Find(x=>x.Name==inp.Item);
                        if(def!=null) GlobalInventoryAPI.Remove(def.Id, inp.Count);
                    }
                    var em = world.EntityManager;
                    var e = em.CreateEntity(typeof(CraftOrder));
                    em.SetComponentData(e, new CraftOrder{ RecipeId = r.Id, TimeRemaining = r.CraftTime });
                }
                GUI.enabled = true;
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();
            GUILayout.EndArea();
        }
    }
}