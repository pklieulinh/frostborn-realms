using UnityEngine;
using UnityEngine.UI;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;
using System.Text;

namespace FrostbornRealms.UI {
    public class TopBarPanel : MonoBehaviour {
        [SerializeField] Text resourceLine;
        [SerializeField] float refreshInterval = 1f;
        float timer;
        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            if(resourceLine == null) return;
            var sb = new StringBuilder();
            int shown = 0;
            foreach(var kv in GlobalInventoryAPI.Enumerate()){
                var def = ItemRegistry.All.Find(x=>x.Id==kv.Key);
                if(def == null) continue;
                if(shown>0) sb.Append(" | ");
                sb.Append(def.Name).Append(":").Append(kv.Value);
                shown++;
                if(shown >= 8) break;
            }
            resourceLine.text = sb.ToString();
        }
    }
}