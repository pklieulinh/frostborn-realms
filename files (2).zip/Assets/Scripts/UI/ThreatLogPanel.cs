using UnityEngine;
using UnityEngine.UI;
using Unity.Entities;
using System.Text;

namespace FrostbornRealms.UI {
    public class ThreatLogPanel : MonoBehaviour {
        [SerializeField] Text logText;
        [SerializeField] int maxLines = 20;
        [SerializeField] float refreshInterval = 1f;
        float timer;
        World world;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }

        void Update(){
            timer += Time.deltaTime;
            if(timer < refreshInterval) return;
            timer = 0;
            if(!world.IsCreated) return;
            if(world.EntityManager.CreateEntityQuery(typeof(ThreatLogTag)).IsEmpty) return;
            var e = world.EntityManager.GetSingletonEntity<ThreatLogTag>();
            var buf = world.EntityManager.GetBuffer<ThreatLogEntry>(e);
            var sb = new StringBuilder();
            int start = Mathf.Max(0, buf.Length - maxLines);
            for(int i=start;i<buf.Length;i++){
                sb.Append(buf[i].Timestamp.ToString("F0")).Append(": ").Append(buf[i].Line.ToString()).Append('\n');
            }
            if(logText) logText.text = sb.ToString();
        }
    }
}