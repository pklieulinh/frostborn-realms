using System.Collections.Generic;
using System.IO;
using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Inventory;
using FrostbornRealms.Doctrine;
using FrostbornRealms.Core;
using FrostbornRealms.ECS.Components;
using FrostbornRealms.Crafting;
using FrostbornRealms.Perishables;
using FrostbornRealms.World;
using FrostbornRealms.Buildings;
using FrostbornRealms.Tasks;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.Heat;
using FrostbornRealms.Telemetry;
using FrostbornRealms.Balancing;
using FrostbornRealms.Threats;
using FrostbornRealms.Navigation;
using FrostbornRealms.Future;
using FrostbornRealms.Research;
using FrostbornRealms.Future.Trade;
using Unity.Mathematics;

namespace FrostbornRealms.SaveLoad {
    [System.Serializable] public class SaveData {
        public float TimeElapsed;
        public Dictionary<int,int> Inventory;
        public Dictionary<int,float> DoctrineProgress;
        public List<CitizenNeeds> Citizens;
        public List<CraftOrderData> CraftOrders;
        public List<PerishableStackData> Perishables;
        public List<ConstructionSiteData> ConstructionSites;
        public List<ResourceNodeData> ResourceNodes;
        public List<BuildingData> Buildings;
        public List<ActiveThreatData> Threats;
        public WeatherData Weather;
        public TimeOfDayData TimeOfDay;
        public EconomyTuningData Economy;
        public List<TelemetrySampleData> TelemetrySamples;
        public ThreatWaveData Wave;
        public NavGridData NavGrid;
        public List<StatusEffectData> StatusEffects;
        public List<TrapData> Traps;
        public List<WallData> Walls;
        public ResearchStateData Research;
        public MarketData Market;
        public List<TradeOfferData> TradeOffers;
        public List<AchievementData> Achievements;
    }
    [System.Serializable] public class CitizenNeeds { public float Hunger, Warmth, Morale, Fatigue; }
    [System.Serializable] public class CraftOrderData { public int RecipeId; public float TimeRemaining; }
    [System.Serializable] public class PerishableStackData { public int ItemId; public int Count; public float Freshness; public float Decay; public int SpoilItemId; }
    [System.Serializable] public class ConstructionSiteData { public int KeyHash; public float WorkRemaining; }
    [System.Serializable] public class ResourceNodeData { public int ResourceKey; public int Remaining; public float Px,Py,Pz; }
    [System.Serializable] public class BuildingData { public int KeyHash; public float Health; public float Max; public float Px,Py,Pz; }
    [System.Serializable] public class ActiveThreatData { public int KindHash; public float TimeRemaining; public float DPS; public byte Flags; }
    [System.Serializable] public class WeatherData { public int Current; public float TimeRemaining; }
    [System.Serializable] public class TimeOfDayData { public float CurrentSeconds; }
    [System.Serializable] public class EconomyTuningData { public float NeedsDecayMultiplier; public float CraftSpeedMultiplier; public float ResourceYieldMultiplier; public float ThreatFrequencyMultiplier; }
    [System.Serializable] public class TelemetrySampleData { public float Time; public float AvgHunger; public float AvgWarmth; public float AvgMorale; }
    [System.Serializable] public class ThreatWaveData { public int WaveNumber; public float TimeSince; public float Scale; }
    [System.Serializable] public class NavGridData { public int Width; public int Height; public float CellSize; public float Ox,Oy,Oz; }
    [System.Serializable] public class StatusEffectData { public int EffectKey; public float Duration; public float Strength; }
    [System.Serializable] public class TrapData { public float Damage; public float Cooldown; public float TimeLeft; public float Px,Py,Pz; }
    [System.Serializable] public class WallData { public float Integrity; public float MaxIntegrity; public float Px,Py,Pz; }
    [System.Serializable] public class ResearchStateData { public float Points; public List<int> Unlocked; }
    [System.Serializable] public class MarketPriceData { public int ItemId; public float Price; public float DemandIndex; }
    [System.Serializable] public class MarketData { public List<MarketPriceData> Prices; }
    [System.Serializable] public class TradeOfferData { public int OfferItemId; public int OfferCount; public int RequestItemId; public int RequestCount; public float TimeRemaining; }
    [System.Serializable] public class AchievementData { public int KeyHash; public byte Unlocked; }

    public static class SaveLoadService {
        static string FilePath => Path.Combine(Application.persistentDataPath, "frostborn_save.json");
        [System.Serializable] class Wrapper { public SaveData Data; }

        public static void Save(World world){
            var data = new SaveData();
            var time = ServiceLocator.Get<TimeService>();
            data.TimeElapsed = time.Elapsed;
            data.Inventory = GlobalInventoryAPI.Snapshot();
            data.DoctrineProgress = DoctrineProgressAPI.Snapshot();

            var em = world.EntityManager;

            data.Citizens = new List<CitizenNeeds>();
            var needsQuery = em.CreateEntityQuery(typeof(Needs));
            using(var arr = needsQuery.ToComponentDataArray<Needs>(Unity.Collections.Allocator.Temp)){
                foreach(var n in arr){
                    data.Citizens.Add(new CitizenNeeds{ Hunger=n.Hunger, Warmth=n.Warmth, Morale=n.Morale, Fatigue=n.Fatigue });
                }
            }

            data.CraftOrders = new List<CraftOrderData>();
            var craftQuery = em.CreateEntityQuery(typeof(CraftOrder));
            using(var arr = craftQuery.ToComponentDataArray<CraftOrder>(Unity.Collections.Allocator.Temp)){
                foreach(var co in arr){
                    data.CraftOrders.Add(new CraftOrderData{ RecipeId=co.RecipeId, TimeRemaining=co.TimeRemaining });
                }
            }

            var perishEntity = em.CreateEntityQuery(typeof(PerishableInventoryTag)).GetSingletonEntity();
            var pBuf = em.GetBuffer<PerishableStack>(perishEntity);
            data.Perishables = new List<PerishableStackData>(pBuf.Length);
            for(int i=0;i<pBuf.Length;i++){
                var s = pBuf[i];
                data.Perishables.Add(new PerishableStackData{
                    ItemId=s.ItemId, Count=s.Count, Freshness=s.Freshness, Decay=s.DecayPerSecond, SpoilItemId=s.SpoilItemId
                });
            }

            data.ConstructionSites = new List<ConstructionSiteData>();
            foreach(var site in em.CreateEntityQuery(typeof(ConstructionSite)).ToComponentDataArray<ConstructionSite>(Unity.Collections.Allocator.Temp)){
                data.ConstructionSites.Add(new ConstructionSiteData{
                    KeyHash=site.KeyHash,
                    WorkRemaining=site.WorkRemaining
                });
            }

            data.ResourceNodes = new List<ResourceNodeData>();
            var nodeQuery = em.CreateEntityQuery(typeof(ResourceNode), typeof(ECS.Components.Position));
            using(var nodes = nodeQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in nodes){
                    var rn = em.GetComponentData<ResourceNode>(e);
                    var pos = em.GetComponentData<ECS.Components.Position>(e);
                    data.ResourceNodes.Add(new ResourceNodeData{
                        ResourceKey=rn.ResourceKey,
                        Remaining=rn.Remaining,
                        Px=pos.Value.x, Py=pos.Value.y, Pz=pos.Value.z
                    });
                }
            }

            data.Buildings = new List<BuildingData>();
            foreach(var e in em.CreateEntityQuery(typeof(Building), typeof(ECS.Components.Position)).ToEntityArray(Unity.Collections.Allocator.Temp)){
                var b = em.GetComponentData<Building>(e);
                var pos = em.GetComponentData<ECS.Components.Position>(e);
                float health = em.HasComponent<BuildingHealth>(e) ? em.GetComponentData<BuildingHealth>(e).Value : 0;
                float max = em.HasComponent<BuildingHealth>(e) ? em.GetComponentData<BuildingHealth>(e).Max : 0;
                data.Buildings.Add(new BuildingData{
                    KeyHash = b.KeyHash,
                    Health = health,
                    Max = max,
                    Px = pos.Value.x,
                    Py = pos.Value.y,
                    Pz = pos.Value.z
                });
            }

            data.Threats = new List<ActiveThreatData>();
            foreach(var t in em.CreateEntityQuery(typeof(ActiveThreat)).ToComponentDataArray<ActiveThreat>(Unity.Collections.Allocator.Temp)){
                data.Threats.Add(new ActiveThreatData{
                    KindHash = t.KindHash,
                    TimeRemaining = t.TimeRemaining,
                    DPS = t.DamagePerSecond,
                    Flags = t.Flags
                });
            }

            var weatherEntity = em.GetSingletonEntity<WeatherStateTag>();
            var ws = em.GetComponentData<WeatherState>(weatherEntity);
            data.Weather = new WeatherData{ Current=(int)ws.Current, TimeRemaining=ws.TimeRemaining };

            var todEntity = em.GetSingletonEntity<TimeOfDayTag>();
            var tod = em.GetComponentData<TimeOfDay>(todEntity);
            data.TimeOfDay = new TimeOfDayData{ CurrentSeconds = tod.CurrentSeconds };

            if(em.CreateEntityQuery(typeof(EconomyTuning)).CalculateEntityCount() > 0){
                var econE = em.GetSingletonEntity<EconomyTuning>();
                var ec = em.GetComponentData<Balancing.EconomyTuning>(econE);
                data.Economy = new EconomyTuningData{
                    NeedsDecayMultiplier = ec.NeedsDecayMultiplier,
                    CraftSpeedMultiplier = ec.CraftSpeedMultiplier,
                    ResourceYieldMultiplier = ec.ResourceYieldMultiplier,
                    ThreatFrequencyMultiplier = ec.ThreatFrequencyMultiplier
                };
            }

            data.TelemetrySamples = new List<TelemetrySampleData>();
            if(em.CreateEntityQuery(typeof(TelemetryBufferTag)).CalculateEntityCount() > 0){
                var tel = em.GetSingletonEntity<TelemetryBufferTag>();
                var bufTel = em.GetBuffer<TelemetrySample>(tel);
                int take = Mathf.Min(32, bufTel.Length);
                for(int i = bufTel.Length - take; i<bufTel.Length; i++){
                    var s = bufTel[i];
                    data.TelemetrySamples.Add(new TelemetrySampleData{
                        Time = s.Time,
                        AvgHunger = s.AvgHunger,
                        AvgWarmth = s.AvgWarmth,
                        AvgMorale = s.AvgMorale
                    });
                }
            }

            if(em.CreateEntityQuery(typeof(ThreatWaveState)).CalculateEntityCount()>0){
                var waveE = em.GetSingletonEntity<ThreatWaveState>();
                var wv = em.GetComponentData<ThreatWaveState>(waveE);
                data.Wave = new ThreatWaveData{
                    WaveNumber = wv.WaveNumber,
                    TimeSince = wv.TimeSinceLastWave,
                    Scale = wv.IntensityScale
                };
            }

            if(em.CreateEntityQuery(typeof(NavGridTag)).CalculateEntityCount()>0){
                var navE = em.GetSingletonEntity<NavGridTag>();
                var cfg = em.GetComponentData<NavGridConfig>(navE);
                data.NavGrid = new NavGridData{
                    Width = cfg.Width,
                    Height = cfg.Height,
                    CellSize = cfg.CellSize,
                    Ox = cfg.Origin.x, Oy = cfg.Origin.y, Oz = cfg.Origin.z
                };
            }

            data.StatusEffects = new List<StatusEffectData>();
            if(em.CreateEntityQuery(typeof(StatusModifierTag)).CalculateEntityCount()>0){
                var stE = em.GetSingletonEntity<StatusModifierTag>();
                var buf = em.GetBuffer<StatusEffect>(stE);
                for(int i=0;i<buf.Length;i++){
                    var s = buf[i];
                    data.StatusEffects.Add(new StatusEffectData{
                        EffectKey = s.EffectKey,
                        Duration = s.Duration,
                        Strength = s.Strength
                    });
                }
            }

            data.Traps = new List<TrapData>();
            foreach(var e in em.CreateEntityQuery(typeof(Future.Trap), typeof(ECS.Components.Position)).ToEntityArray(Unity.Collections.Allocator.Temp)){
                var tr = em.GetComponentData<Future.Trap>(e);
                var pos = em.GetComponentData<ECS.Components.Position>(e);
                data.Traps.Add(new TrapData{
                    Damage = tr.Damage,
                    Cooldown = tr.Cooldown,
                    TimeLeft = tr.TimeLeft,
                    Px = pos.Value.x, Py=pos.Value.y, Pz=pos.Value.z
                });
            }

            data.Walls = new List<WallData>();
            foreach(var e in em.CreateEntityQuery(typeof(Future.WallSection), typeof(ECS.Components.Position)).ToEntityArray(Unity.Collections.Allocator.Temp)){
                var w = em.GetComponentData<Future.WallSection>(e);
                var pos = em.GetComponentData<ECS.Components.Position>(e);
                data.Walls.Add(new WallData{
                    Integrity = w.Integrity,
                    MaxIntegrity = w.MaxIntegrity,
                    Px = pos.Value.x, Py=pos.Value.y, Pz=pos.Value.z
                });
            }

            data.Research = new ResearchStateData{ Unlocked = new List<int>(), Points = 0 };
            if(em.CreateEntityQuery(typeof(ResearchStateTag)).CalculateEntityCount()>0){
                var rsEnt = em.GetSingletonEntity<ResearchStateTag>();
                var rbuf = em.GetBuffer<ResearchUnlocked>(rsEnt);
                for(int i=0;i<rbuf.Length;i++) data.Research.Unlocked.Add(rbuf[i].KeyHash);
            }
            if(em.CreateEntityQuery(typeof(ResearchPointsTag)).CalculateEntityCount()>0){
                var rp = em.GetComponentData<ResearchPointsTag>(em.GetSingletonEntity<ResearchPointsTag>());
                data.Research.Points = rp.Points;
            }

            data.Market = new MarketData{ Prices = new List<MarketPriceData>() };
            if(em.CreateEntityQuery(typeof(MarketStateTag)).CalculateEntityCount()>0){
                var mEnt = em.GetSingletonEntity<MarketStateTag>();
                var pBuf = em.GetBuffer<MarketPrice>(mEnt);
                for(int i=0;i<pBuf.Length;i++){
                    var p = pBuf[i];
                    data.Market.Prices.Add(new MarketPriceData{
                        ItemId = p.ItemId,
                        Price = p.Price,
                        DemandIndex = p.DemandIndex
                    });
                }
            }

            data.TradeOffers = new List<TradeOfferData>();
            if(em.CreateEntityQuery(typeof(TradeOfferTag)).CalculateEntityCount()>0){
                var tEnt = em.GetSingletonEntity<TradeOfferTag>();
                var tBuf = em.GetBuffer<TradeOffer>(tEnt);
                for(int i=0;i<tBuf.Length;i++){
                    var o = tBuf[i];
                    if(o.Accepted == 0){
                        data.TradeOffers.Add(new TradeOfferData{
                            OfferItemId = o.OfferItemId,
                            OfferCount = o.OfferCount,
                            RequestItemId = o.RequestItemId,
                            RequestCount = o.RequestCount,
                            TimeRemaining = o.TimeRemaining
                        });
                    }
                }
            }

            data.Achievements = new List<AchievementData>();
            if(em.CreateEntityQuery(typeof(AchievementTag)).CalculateEntityCount()>0){
                var aEnt = em.GetSingletonEntity<AchievementTag>();
                var aBuf = em.GetBuffer<AchievementEntry>(aEnt);
                for(int i=0;i<aBuf.Length;i++){
                    var ae = aBuf[i];
                    if(ae.Unlocked == 1)
                        data.Achievements.Add(new AchievementData{ KeyHash = ae.KeyHash, Unlocked = ae.Unlocked });
                }
            }

            var json = JsonUtility.ToJson(new Wrapper{ Data=data }, true);
            File.WriteAllText(FilePath, json);
            Debug.Log($"[SaveLoad] Saved {FilePath}");
        }

        public static void Load(World world){
            if(!File.Exists(FilePath)){
                Debug.LogWarning("[SaveLoad] No save file");
                return;
            }
            var json = File.ReadAllText(FilePath);
            var wrap = JsonUtility.FromJson<Wrapper>(json);
            var data = wrap.Data;
            var em = world.EntityManager;

            // Citizens
            var needsQuery = em.CreateEntityQuery(typeof(Needs));
            using(var ents = needsQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents) em.DestroyEntity(e);
            }
            foreach(var c in data.Citizens){
                var e = em.CreateEntity(typeof(Needs));
                em.SetComponentData(e, new Needs{ Hunger=c.Hunger, Warmth=c.Warmth, Morale=c.Morale, Fatigue=c.Fatigue });
            }

            GlobalInventoryAPI.LoadSnapshot(data.Inventory);
            DoctrineProgressAPI.Load(data.DoctrineProgress);

            // Craft
            var craftQuery = em.CreateEntityQuery(typeof(CraftOrder));
            using(var ents = craftQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents) em.DestroyEntity(e);
            }
            foreach(var co in data.CraftOrders){
                var e = em.CreateEntity(typeof(CraftOrder));
                em.SetComponentData(e, new CraftOrder{ RecipeId=co.RecipeId, TimeRemaining=co.TimeRemaining });
            }

            // Perishables
            if(em.CreateEntityQuery(typeof(PerishableInventoryTag)).CalculateEntityCount()>0){
                var perishEntity = em.GetSingletonEntity<PerishableInventoryTag>();
                var pBuf = em.GetBuffer<PerishableStack>(perishEntity);
                pBuf.Clear();
                if(data.Perishables != null){
                    foreach(var s in data.Perishables){
                        pBuf.Add(new PerishableStack{
                            ItemId=s.ItemId, Count=s.Count, Freshness=s.Freshness, DecayPerSecond=s.Decay, SpoilItemId=s.SpoilItemId
                        });
                    }
                }
            }

            // Construction sites
            var siteQuery = em.CreateEntityQuery(typeof(ConstructionSite));
            using(var ents = siteQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents) em.DestroyEntity(e);
            }
            if(data.ConstructionSites!=null){
                foreach(var s in data.ConstructionSites){
                    var e = em.CreateEntity(typeof(ConstructionSite));
                    em.SetComponentData(e, new ConstructionSite{ KeyHash=s.KeyHash, WorkRemaining=s.WorkRemaining });
                }
            }

            // Resource nodes
            var nodeQuery = em.CreateEntityQuery(typeof(ResourceNode));
            using(var ents = nodeQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents) em.DestroyEntity(e);
            }
            if(data.ResourceNodes!=null){
                foreach(var rn in data.ResourceNodes){
                    var e = em.CreateEntity(typeof(ResourceNode), typeof(ECS.Components.Position));
                    em.SetComponentData(e, new ResourceNode{ ResourceKey=rn.ResourceKey, Remaining=rn.Remaining });
                    em.SetComponentData(e, new ECS.Components.Position{ Value = new float3(rn.Px,rn.Py,rn.Pz)});
                }
            }

            // Buildings
            var bQuery = em.CreateEntityQuery(typeof(Building));
            using(var ents = bQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents) em.DestroyEntity(e);
            }
            if(data.Buildings!=null){
                foreach(var b in data.Buildings){
                    var be = em.CreateEntity(typeof(Building), typeof(BuildingHealth), typeof(ECS.Components.Position));
                    em.SetComponentData(be, new Building{ KeyHash = b.KeyHash });
                    em.SetComponentData(be, new BuildingHealth{ Value = b.Health, Max = b.Max });
                    em.SetComponentData(be, new ECS.Components.Position{ Value = new float3(b.Px,b.Py,b.Pz)});
                }
            }

            // Threats
            var tQuery = em.CreateEntityQuery(typeof(ActiveThreat));
            using(var ents = tQuery.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents) em.DestroyEntity(e);
            }
            if(data.Threats != null){
                foreach(var t in data.Threats){
                    var e = em.CreateEntity(typeof(ActiveThreat));
                    em.SetComponentData(e, new ActiveThreat{
                        KindHash = t.KindHash,
                        TimeRemaining = t.TimeRemaining,
                        DamagePerSecond = t.DPS,
                        Flags = t.Flags
                    });
                }
            }

            // Weather
            var weatherEntity = em.GetSingletonEntity<WeatherStateTag>();
            var ws = em.GetComponentData<WeatherState>(weatherEntity);
            ws.Current = (World.WeatherType)data.Weather.Current;
            ws.TimeRemaining = data.Weather.TimeRemaining;
            em.SetComponentData(weatherEntity, ws);

            // Time of Day
            var todEntity = em.GetSingletonEntity<TimeOfDayTag>();
            var tod = em.GetComponentData<TimeOfDay>(todEntity);
            tod.CurrentSeconds = data.TimeOfDay.CurrentSeconds;
            em.SetComponentData(todEntity, tod);

            // Economy
            if(data.Economy != null && em.CreateEntityQuery(typeof(EconomyTuning)).CalculateEntityCount()>0){
                var econE = em.GetSingletonEntity<EconomyTuning>();
                var t = em.GetComponentData<Balancing.EconomyTuning>(econE);
                t.NeedsDecayMultiplier = data.Economy.NeedsDecayMultiplier;
                t.CraftSpeedMultiplier = data.Economy.CraftSpeedMultiplier;
                t.ResourceYieldMultiplier = data.Economy.ResourceYieldMultiplier;
                t.ThreatFrequencyMultiplier = data.Economy.ThreatFrequencyMultiplier;
                em.SetComponentData(econE, t);
            }

            // Telemetry
            if(data.TelemetrySamples != null && em.CreateEntityQuery(typeof(TelemetryBufferTag)).CalculateEntityCount()>0){
                var tel = em.GetSingletonEntity<TelemetryBufferTag>();
                var buffer = em.GetBuffer<TelemetrySample>(tel);
                buffer.Clear();
                foreach(var s in data.TelemetrySamples){
                    buffer.Add(new TelemetrySample{
                        Time = s.Time,
                        AvgHunger = s.AvgHunger,
                        AvgWarmth = s.AvgWarmth,
                        AvgMorale = s.AvgMorale
                    });
                }
            }

            // Wave
            if(data.Wave != null && em.CreateEntityQuery(typeof(ThreatWaveState)).CalculateEntityCount()>0){
                var waveE = em.GetSingletonEntity<ThreatWaveState>();
                var wv = em.GetComponentData<ThreatWaveState>(waveE);
                wv.WaveNumber = data.Wave.WaveNumber;
                wv.TimeSinceLastWave = data.Wave.TimeSince;
                wv.IntensityScale = data.Wave.Scale;
                em.SetComponentData(waveE, wv);
            }

            // NavGrid
            if(data.NavGrid != null && em.CreateEntityQuery(typeof(NavGridTag)).CalculateEntityCount()>0){
                var navE = em.GetSingletonEntity<NavGridTag>();
                var cfg = em.GetComponentData<NavGridConfig>(navE);
                cfg.Width = data.NavGrid.Width;
                cfg.Height = data.NavGrid.Height;
                cfg.CellSize = data.NavGrid.CellSize;
                cfg.Origin = new float3(data.NavGrid.Ox, data.NavGrid.Oy, data.NavGrid.Oz);
                em.SetComponentData(navE, cfg);
                em.GetBuffer<NavGridCell>(navE).Clear();
            }

            // Status Effects
            if(data.StatusEffects != null){
                if(em.CreateEntityQuery(typeof(StatusModifierTag)).CalculateEntityCount()==0){
                    var se = em.CreateEntity(typeof(StatusModifierTag));
                    em.AddBuffer<StatusEffect>(se);
                }
                var stE = em.GetSingletonEntity<StatusModifierTag>();
                var buf = em.GetBuffer<StatusEffect>(stE);
                buf.Clear();
                foreach(var s in data.StatusEffects){
                    buf.Add(new StatusEffect{
                        EffectKey = s.EffectKey,
                        Duration = s.Duration,
                        Strength = s.Strength
                    });
                }
            }

            // Traps
            foreach(var e in em.CreateEntityQuery(typeof(Future.Trap)).ToEntityArray(Unity.Collections.Allocator.Temp)){
                em.DestroyEntity(e);
            }
            if(data.Traps != null){
                foreach(var tr in data.Traps){
                    var ent = em.CreateEntity(typeof(Future.Trap), typeof(ECS.Components.Position));
                    em.SetComponentData(ent, new Future.Trap{
                        Damage = tr.Damage,
                        Cooldown = tr.Cooldown,
                        TimeLeft = tr.TimeLeft
                    });
                    em.SetComponentData(ent, new ECS.Components.Position{ Value = new float3(tr.Px,tr.Py,tr.Pz)});
                }
            }

            // Walls
            foreach(var e in em.CreateEntityQuery(typeof(Future.WallSection)).ToEntityArray(Unity.Collections.Allocator.Temp)){
                em.DestroyEntity(e);
            }
            if(data.Walls != null){
                foreach(var w in data.Walls){
                    var ent = em.CreateEntity(typeof(Future.WallSection), typeof(ECS.Components.Position));
                    em.SetComponentData(ent, new Future.WallSection{
                        Integrity = w.Integrity,
                        MaxIntegrity = w.MaxIntegrity,
                        DirtyNav = 1
                    });
                    em.SetComponentData(ent, new ECS.Components.Position{ Value = new float3(w.Px,w.Py,w.Pz)});
                }
            }

            // Research
            if(em.CreateEntityQuery(typeof(ResearchStateTag)).CalculateEntityCount()==0){
                var rs = em.CreateEntity(typeof(ResearchStateTag));
                em.AddBuffer<ResearchUnlocked>(rs);
            }
            var rsEntLoad = em.GetSingletonEntity<ResearchStateTag>();
            var rbuffer = em.GetBuffer<ResearchUnlocked>(rsEntLoad);
            rbuffer.Clear();
            if(data.Research != null && data.Research.Unlocked != null){
                foreach(var h in data.Research.Unlocked){
                    rbuffer.Add(new ResearchUnlocked{ KeyHash = h });
                }
            }
            if(em.CreateEntityQuery(typeof(ResearchPointsTag)).CalculateEntityCount()==0){
                em.CreateEntity(typeof(ResearchPointsTag));
            }
            var rpEnt = em.GetSingletonEntity<ResearchPointsTag>();
            var rp = em.GetComponentData<ResearchPointsTag>(rpEnt);
            rp.Points = data.Research != null ? data.Research.Points : 0;
            em.SetComponentData(rpEnt, rp);

            // Market
            if(data.Market != null){
                if(em.CreateEntityQuery(typeof(MarketStateTag)).CalculateEntityCount()==0){
                    var mEnt = em.CreateEntity(typeof(MarketStateTag));
                    em.AddBuffer<MarketPrice>(mEnt);
                }
                var mState = em.GetSingletonEntity<MarketStateTag>();
                var mBuf = em.GetBuffer<MarketPrice>(mState);
                mBuf.Clear();
                if(data.Market.Prices != null){
                    foreach(var p in data.Market.Prices){
                        mBuf.Add(new MarketPrice{
                            ItemId = p.ItemId,
                            Price = p.Price,
                            DemandIndex = p.DemandIndex
                        });
                    }
                }
            }

            // Trade offers
            if(em.CreateEntityQuery(typeof(TradeOfferTag)).CalculateEntityCount()==0){
                var to = em.CreateEntity(typeof(TradeOfferTag));
                em.AddBuffer<TradeOffer>(to);
            }
            var offerEnt = em.GetSingletonEntity<TradeOfferTag>();
            var offerBuf = em.GetBuffer<TradeOffer>(offerEnt);
            offerBuf.Clear();
            if(data.TradeOffers != null){
                foreach(var o in data.TradeOffers){
                    offerBuf.Add(new TradeOffer{
                        OfferItemId = o.OfferItemId,
                        OfferCount = o.OfferCount,
                        RequestItemId = o.RequestItemId,
                        RequestCount = o.RequestCount,
                        TimeRemaining = o.TimeRemaining,
                        Accepted = 0
                    });
                }
            }

            // Achievements
            if(em.CreateEntityQuery(typeof(AchievementTag)).CalculateEntityCount()==0){
                var ach = em.CreateEntity(typeof(AchievementTag));
                em.AddBuffer<AchievementEntry>(ach);
            }
            var achEnt = em.GetSingletonEntity<AchievementTag>();
            var achBuf = em.GetBuffer<AchievementEntry>(achEnt);
            achBuf.Clear();
            if(data.Achievements != null){
                foreach(var a in data.Achievements){
                    achBuf.Add(new AchievementEntry{
                        KeyHash = a.KeyHash,
                        Unlocked = a.Unlocked
                    });
                }
            }

            Debug.Log("[SaveLoad] Load complete");
        }
    }
}