#if ENABLE_LEGACY_DEBUG
using UnityEngine;
using Unity.Entities;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.DebugUI {
    public class LegacyDebugHUD : MonoBehaviour {
        Rect rect = new Rect(10,10,360,220);
        bool visible = true;
        World world;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }
        void Update(){
            if(Input.GetKeyDown(KeyCode.F12)) visible = !visible;
        }
        void OnGUI(){
            if(!visible) return;
            GUILayout.BeginArea(rect, GUI.skin.box);
            GUILayout.Label("Legacy HUD");
            GUILayout.EndArea();
        }
    }
}
#endif