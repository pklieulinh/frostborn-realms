using Unity.Entities;
using UnityEngine;
using FrostbornRealms.Core;
using FrostbornRealms.Threats;
using FrostbornRealms.Effects;
using Unity.Mathematics;
using FrostbornRealms.Balancing;
using FrostbornRealms.UI;

namespace FrostbornRealms.ECS.Systems {
    public partial struct ThreatSchedulerSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        float timer;
        public void OnUpdate(ref SystemState state){
            var cfg = ServiceLocator.Get<SimulationConfig>();
            timer += SystemAPI.Time.DeltaTime;
            var econ = SystemAPI.HasSingleton<EconomyTuning>() ? SystemAPI.GetSingleton<EconomyTuning>() : EconomyTuning.Default();
            float interval = cfg.ThreatCheckInterval / math.max(0.25f, econ.ThreatFrequencyMultiplier);
            if(timer < interval) return;
            timer = 0;
            var rng = ServiceLocator.Get<RandomService>();
            if(rng.Value.NextFloat() > cfg.ThreatProbability) return;

            var waveEntity = SystemAPI.GetSingletonEntity<ThreatWaveState>();
            var wave = SystemAPI.GetComponent<ThreatWaveState>(waveEntity);

            int roll = rng.Value.NextInt(0, 100);
            int kindHash;
            if(roll < 40) kindHash = "WolfPack".GetHashCode();
            else if(roll < 70) kindHash = "NightRaid".GetHashCode();
            else kindHash = "BlizzardStorm".GetHashCode();

            float intensity = math.max(1f, wave.IntensityScale);
            var req = state.EntityManager.CreateEntity(typeof(ThreatSpawnRequest));
            state.EntityManager.SetComponentData(req, new ThreatSpawnRequest{
                KindHash = kindHash,
                Intensity = intensity
            });
            ThreatLogger.Add(state.WorldUnmanaged.World, $"Scheduled Threat {kindHash} intensity {intensity:F1}");
        }
    }

    public partial struct ThreatWaveAdvanceSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var cfg = ServiceLocator.Get<SimulationConfig>();
            var waveEntity = SystemAPI.GetSingletonEntity<ThreatWaveState>();
            var wave = SystemAPI.GetComponent<ThreatWaveState>(waveEntity);
            wave.TimeSinceLastWave += SystemAPI.Time.DeltaTime;
            if(wave.TimeSinceLastWave >= cfg.WaveInterval){
                wave.TimeSinceLastWave = 0;
                wave.WaveNumber++;
                wave.IntensityScale *= cfg.WaveIntensityGrowth;
                ThreatLogger.Add(state.WorldUnmanaged.World, $"Wave {wave.WaveNumber} scale {wave.IntensityScale:F2}");
            }
            SystemAPI.SetComponent(waveEntity, wave);
        }
    }

    public partial struct ThreatResolutionSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            foreach(var (req, entity) in SystemAPI.Query<ThreatSpawnRequest>().WithEntityAccess()){
                var threat = state.EntityManager.CreateEntity(typeof(ActiveThreat));
                float duration = 30f;
                float dps = 2f * req.Intensity;
                if(req.KindHash == "WolfPack".GetHashCode()){
                    duration = 25f;
                    dps = 4f * req.Intensity;
                    ThreatLogger.Add(state.WorldUnmanaged.World, "WolfPack arrived");
                } else if(req.KindHash == "NightRaid".GetHashCode()){
                    duration = 10f;
                    dps = 0;
                    ThreatLogger.Add(state.WorldUnmanaged.World, "NightRaid triggered");
                } else if(req.KindHash == "BlizzardStorm".GetHashCode()){
                    duration = 35f;
                    dps = 0;
                    ThreatLogger.Add(state.WorldUnmanaged.World, "BlizzardStorm rolling in");
                }
                state.EntityManager.SetComponentData(threat, new ActiveThreat{
                    KindHash = req.KindHash,
                    TimeRemaining = duration,
                    DamagePerSecond = dps,
                    Flags = 0
                });
                state.EntityManager.DestroyEntity(entity);
            }
        }
    }

    public partial struct ActiveThreatRuntimeSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);
            foreach(var (th, entity) in SystemAPI.Query<RefRW<ActiveThreat>>().WithEntityAccess()){
                var t = th.ValueRO;
                t.TimeRemaining -= SystemAPI.Time.DeltaTime;
                if(t.TimeRemaining <=0){
                    ThreatLogger.Add(state.WorldUnmanaged.World, $"Threat {t.KindHash} resolved");
                    ecb.DestroyEntity(entity);
                    continue;
                }
                th.ValueRW = t;
            }
            ecb.Playback(state.EntityManager);
        }
    }
}