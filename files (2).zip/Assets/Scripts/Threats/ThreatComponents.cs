using Unity.Entities;

namespace FrostbornRealms.Threats {
    public struct ThreatSpawnRequest : IComponentData {
        public int KindHash;
        public float Intensity;
    }
    public struct ActiveThreat : IComponentData {
        public int KindHash;
        public float TimeRemaining;
        public float DamagePerSecond;
        public byte Flags; // bitmask
    }
    public struct ThreatWaveState : IComponentData {
        public int WaveNumber;
        public float TimeSinceLastWave;
        public float IntensityScale;
    }
    public struct BuildingHealth : IComponentData {
        public float Value;
        public float Max;
    }
    public struct StatusModifierTag : IComponentData {}
    public struct StatusEffect : IBufferElementData {
        public int EffectKey;
        public float Duration;
        public float Strength;
    }
}