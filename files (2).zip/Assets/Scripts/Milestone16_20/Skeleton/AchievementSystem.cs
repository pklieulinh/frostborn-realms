using Unity.Entities;
using Unity.Collections;

namespace FrostbornRealms.Future {
    public struct AchievementTag : IComponentData {}
    public struct AchievementEntry : IBufferElementData {
        public int KeyHash;
        public byte Unlocked;
    }

    public partial struct AchievementSystem : ISystem {
        public void OnCreate(ref SystemState state){
            var e = state.EntityManager.CreateEntity(typeof(AchievementTag));
            state.EntityManager.AddBuffer<AchievementEntry>(e);
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            // TODO: scan conditions
        }
    }
}