using Unity.Entities;

namespace FrostbornRealms.Future {
    public struct ModRegistryTag : IComponentData {}

    public partial struct ModIntegrationSystem : ISystem {
        public void OnCreate(ref SystemState state){
            state.EntityManager.CreateEntity(typeof(ModRegistryTag));
            // TODO: load mod JSON descriptors from StreamingAssets/ModsV2
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            // TODO: hot reload detection
        }
    }
}