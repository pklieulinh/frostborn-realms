using Unity.Entities;
using FrostbornRealms.Future.Trade;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;
using FrostbornRealms.UI;
using FrostbornRealms.Core;
using Unity.Mathematics;

namespace FrostbornRealms.ECS.Systems {
    public struct MarketRuntimeTag : IComponentData {
        public float TimeSinceLastCaravan;
    }

    public partial struct TradeEconomySystem : ISystem {
        public void OnCreate(ref SystemState state){
            if(!SystemAPI.HasSingleton<MarketStateTag>()){
                var e = state.EntityManager.CreateEntity(typeof(MarketStateTag));
                state.EntityManager.AddBuffer<MarketPrice>(e);
            }
            if(!SystemAPI.HasSingleton<MarketRuntimeTag>()){
                state.EntityManager.CreateEntity(typeof(MarketRuntimeTag));
            }
            if(!SystemAPI.HasSingleton<TradeOfferTag>()){
                var e = state.EntityManager.CreateEntity(typeof(TradeOfferTag));
                state.EntityManager.AddBuffer<TradeOffer>(e);
            }
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            // Price smoothing (simple demand drift back to 1)
            var market = SystemAPI.GetSingletonEntity<MarketStateTag>();
            var prices = state.EntityManager.GetBuffer<MarketPrice>(market);
            for(int i=0;i<prices.Length;i++){
                var p = prices[i];
                p.DemandIndex = math.lerp(p.DemandIndex, 1f, SystemAPI.Time.DeltaTime * 0.1f);
                prices[i] = p;
            }
        }
    }

    public partial struct CaravanSpawnerSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var cfg = ServiceLocator.Get<SimulationConfig>();
            if(!SystemAPI.HasSingleton<MarketRuntimeTag>()) return;
            var runEnt = SystemAPI.GetSingletonEntity<MarketRuntimeTag>();
            var rt = SystemAPI.GetComponent<MarketRuntimeTag>(runEnt);
            rt.TimeSinceLastCaravan += SystemAPI.Time.DeltaTime;
            if(rt.TimeSinceLastCaravan < 90f) { SystemAPI.SetComponent(runEnt, rt); return; }
            rt.TimeSinceLastCaravan = 0;
            SystemAPI.SetComponent(runEnt, rt);
            // Spawn trade offers
            var offerEnt = SystemAPI.GetSingletonEntity<TradeOfferTag>();
            var buf = SystemAPI.GetBuffer<TradeOffer>(offerEnt);
            // Simple: create up to 2 offers if below threshold
            if(buf.Length < 4){
                // Map some items by name
                int woodId = FindItemId("Wood");
                int berriesId = FindItemId("Berries");
                if(woodId!=0 && berriesId!=0){
                    buf.Add(new TradeOffer{
                        OfferItemId = berriesId,
                        OfferCount = 10,
                        RequestItemId = woodId,
                        RequestCount = 8,
                        TimeRemaining = 60f,
                        Accepted = 0
                    });
                }
            }
            EventLogger.Add(state.WorldUnmanaged.World, "Caravan arrived with trade offers.");
        }

        int FindItemId(string name){
            var it = ItemRegistry.All.Find(x=>x.Name==name);
            return it!=null ? it.Id : 0;
        }
    }

    public partial struct TradeOfferLifetimeSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var ent = SystemAPI.GetSingletonEntity<TradeOfferTag>();
            var buf = state.EntityManager.GetBuffer<TradeOffer>(ent);
            for(int i=buf.Length-1;i>=0;i--){
                var t = buf[i];
                t.TimeRemaining -= SystemAPI.Time.DeltaTime;
                if(t.TimeRemaining <=0 || t.Accepted == 1){
                    buf.RemoveAt(i);
                } else {
                    buf[i]=t;
                }
            }
        }
    }

    public partial struct TradeResolutionSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            foreach(var (req, entity) in SystemAPI.Query<TradeAcceptRequest>().WithEntityAccess()){
                var offersEnt = SystemAPI.GetSingletonEntity<TradeOfferTag>();
                var buf = state.EntityManager.GetBuffer<TradeOffer>(offersEnt);
                if(req.OfferIndex >=0 && req.OfferIndex < buf.Length){
                    var off = buf[req.OfferIndex];
                    // Validate inventory for payment
                    if(GlobalInventoryAPI.Remove(off.RequestItemId, off.RequestCount)){
                        GlobalInventoryAPI.Add(off.OfferItemId, off.OfferCount);
                        off.Accepted = 1;
                        buf[req.OfferIndex] = off;
                        EventLogger.Add(state.WorldUnmanaged.World, "Trade accepted.");
                        // Mark achievement
                        TradeAchievementFlagSystem.MarkTrade(state.EntityManager);
                    }
                }
                state.EntityManager.DestroyEntity(entity);
            }
        }
    }

    static class TradeAchievementFlagSystem {
        static bool executed;
        public static void MarkTrade(EntityManager em){
            if(executed) return;
            if(!em.CreateEntityQuery(typeof(FrostbornRealms.Future.AchievementTag)).IsEmpty){
                var achEnt = em.GetSingletonEntity<FrostbornRealms.Future.AchievementTag>();
                var buf = em.GetBuffer<FrostbornRealms.Future.AchievementEntry>(achEnt);
                // We'll just set a dummy entry to signal trade occurred for achievement scanning.
                buf.Add(new FrostbornRealms.Future.AchievementEntry{
                    KeyHash = "TradeMarker".GetHashCode(),
                    Unlocked = 2 // 2 = marker
                });
            }
            executed = true;
        }
    }
}