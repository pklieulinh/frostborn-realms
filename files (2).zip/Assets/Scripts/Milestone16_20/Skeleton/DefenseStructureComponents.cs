using Unity.Entities;

namespace FrostbornRealms.Future {
    public struct Trap : IComponentData {
        public float Damage;
        public float Cooldown;
        public float TimeLeft;
    }
    public struct WallSection : IComponentData {
        public float Integrity;
        public float MaxIntegrity;
    }
}