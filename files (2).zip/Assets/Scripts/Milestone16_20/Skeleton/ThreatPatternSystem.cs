using Unity.Entities;

namespace FrostbornRealms.Future {
    // Milestone 16 skeleton: complex threat pattern orchestration
    public struct ThreatScenarioTag : IComponentData {}
    public partial struct ThreatPatternSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            // TODO: pattern scheduler (multi-phase waves)
        }
    }
}