using Unity.Entities;

namespace FrostbornRealms.Future {
    public partial struct TrapSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            // TODO: scan threats near traps reduce HP
        }
    }
    public partial struct WallIntegritySystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            // TODO: apply damage distribution
        }
    }
}