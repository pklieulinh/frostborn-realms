using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Core;
using FrostbornRealms.Data;
using FrostbornRealms.Assets;
using FrostbornRealms.Visual;
using FrostbornRealms.Audio;
using FrostbornRealms.Inventory;
using FrostbornRealms.Effects;
using FrostbornRealms.Doctrine;
using FrostbornRealms.Heat;
using FrostbornRealms.World;
using FrostbornRealms.Perishables;
using FrostbornRealms.Buildings;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.Tasks;
using FrostbornRealms.Threats;
using FrostbornRealms.Telemetry;
using FrostbornRealms.Balancing;
using FrostbornRealms.Navigation;
using FrostbornRealms.UI;
using Unity.Mathematics;

namespace FrostbornRealms {
    public class GameBootstrap : MonoBehaviour {
        [SerializeField] int seed = 12345;
        [SerializeField] SimulationConfig config;
        [SerializeField] AssetManifest assetManifest;
        public bool AutoSpawnHeatSource = true;
        public int InitialCitizens = 5;
        public int NavGridWidth = 64;
        public int NavGridHeight = 64;
        public float NavCellSize = 1f;
        public UIManager uiManagerPrefab;

        void Awake(){
            if(config == null) config = ScriptableObject.CreateInstance<SimulationConfig>();
            ServiceLocator.Register(new TimeService());
            ServiceLocator.Register(new RandomService(seed));
            ServiceLocator.Register(config);

            RegistryBootstrap.LoadAll("Mods");
            if(assetManifest){
                AssetResolver.Initialize(assetManifest);
                MaterialLibrary.Initialize();
                AudioManager.Instance.PlayAmbient("sfx_wind_loop");
            }

            var world = World.DefaultGameObjectInjectionWorld;
            var em = world.EntityManager;

            var inventoryEntity = em.CreateEntity(typeof(GlobalInventoryTag));
            em.AddBuffer<InventoryItemSlot>(inventoryEntity);
            em.AddComponentData(inventoryEntity, new CategoryAggregate());
            GlobalInventoryAPI.Init(inventoryEntity, em);

            var effectEntity = em.CreateEntity(typeof(EffectQueueTag));
            em.AddBuffer<EffectToken>(effectEntity);
            em.AddBuffer<EffectActionBuffer>(effectEntity);

            var doctrineEntity = em.CreateEntity(typeof(DoctrineProgressTag));
            em.AddBuffer<DoctrineProgressEntry>(doctrineEntity);
            DoctrineProgressAPI.Init(doctrineEntity, em);

            var heatGridEntity = em.CreateEntity(typeof(HeatGridTag));
            em.AddComponentData(heatGridEntity, new HeatGridSettings{
                CellSize = config.HeatGridCellSize,
                RebuildInterval = config.HeatGridRebuildInterval,
                TimeSinceRebuild = 0
            });
            em.AddBuffer<HeatSourceBucket>(heatGridEntity);

            var perishEntity = em.CreateEntity(typeof(PerishableInventoryTag));
            em.AddBuffer<PerishableStack>(perishEntity);
            PerishableInventoryAPI.Init(perishEntity, em);

            var timeEntity = em.CreateEntity(typeof(TimeOfDayTag));
            em.AddComponentData(timeEntity, new TimeOfDay{
                DayLengthSeconds = config.DayLengthSeconds,
                CurrentSeconds = 0
            });

            var weatherEntity = em.CreateEntity(typeof(WeatherStateTag));
            em.AddComponentData(weatherEntity, new WeatherState{
                Current = WeatherType.Clear,
                TimeRemaining = config.WeatherBaseDuration
            });

            var taskQueueEntity = em.CreateEntity(typeof(TaskQueueTag));
            em.AddBuffer<TaskRequest>(taskQueueEntity);

            var telemetryEntity = em.CreateEntity(typeof(TelemetryBufferTag));
            em.AddBuffer<TelemetrySample>(telemetryEntity);
            em.AddComponentData(telemetryEntity, new TelemetryRuntime{
                TimeSinceLast = 0,
                Interval = config.TelemetryInterval
            });

            var tuningEntity = em.CreateEntity(typeof(EconomyTuning));
            em.SetComponentData(tuningEntity, EconomyTuning.Default());

            var waveEntity = em.CreateEntity(typeof(ThreatWaveState));
            em.SetComponentData(waveEntity, new ThreatWaveState{
                WaveNumber = 0,
                TimeSinceLastWave = 0,
                IntensityScale = 1f
            });

            var navEntity = em.CreateEntity(typeof(NavGridTag));
            em.AddBuffer<NavGridCell>(navEntity);
            em.SetComponentData(navEntity, new NavGridConfig{
                Width = NavGridWidth,
                Height = NavGridHeight,
                CellSize = NavCellSize,
                Origin = new float3(-NavGridWidth*NavCellSize*0.5f,0,-NavGridHeight*NavCellSize*0.5f)
            });

            if(AutoSpawnHeatSource){
                var src = em.CreateEntity(typeof(ECS.Components.Position), typeof(HeatSource), typeof(Temperature));
                em.SetComponentData(src, new ECS.Components.Position{ Value = new float3(0,0,0)});
                em.SetComponentData(src, new HeatSource{ Intensity = 80f, Radius = 25f});
                em.SetComponentData(src, new Temperature{ Value = config.AmbientTemperature + 40f});
            }

            for(int i=0;i<InitialCitizens;i++){
                var c = em.CreateEntity(typeof(ECS.Components.Position), typeof(ECS.Components.Needs), typeof(CitizenTag), typeof(MovementSpeed));
                em.SetComponentData(c, new ECS.Components.Position{ Value = new float3(i*1.5f,0,0)});
                em.SetComponentData(c, new MovementSpeed{ Value = 4f });
            }

            for(int i=0;i<6;i++){
                var n = em.CreateEntity(typeof(ECS.Components.Position), typeof(ResourceNode));
                em.SetComponentData(n, new ECS.Components.Position{ Value = new float3(10 + i*2f,0,0)});
                em.SetComponentData(n, new ResourceNode{
                    ResourceKey = ResourceNodeKeys.WoodPile,
                    Remaining = 30 + i*10
                });
            }

            EnsureMono<HeatOverlayGizmo>("HeatOverlayGizmo");
            EnsureMono<ConstructionProgressRenderer>("ConstructionProgressRenderer");
            EnsureMono<WeatherParticleController>("WeatherParticles");
            EnsureMono<HeatFieldOverlay>("HeatFieldOverlay");
            EnsureMono<CitizenBatchRenderer>("CitizenBatchRenderer");
            EnsureMono<ResourceNodeBillboard>("ResourceNodeBillboard");
            if(FindObjectOfType<UIManager>() == null){
                if(uiManagerPrefab != null) Instantiate(uiManagerPrefab);
                else {
                    var go = new GameObject("UIManager");
                    go.AddComponent<UIManager>();
                }
            }
        }

        void EnsureMono<T>(string name) where T: Component {
            if(FindObjectOfType<T>() == null){
                var go = new GameObject(name);
                go.AddComponent<T>();
            }
        }

        void Update(){
            ServiceLocator.Get<TimeService>().Tick(Time.deltaTime);
        }
    }
}