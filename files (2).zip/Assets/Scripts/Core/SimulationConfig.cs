using UnityEngine;

namespace FrostbornRealms.Core {
    [CreateAssetMenu(fileName = "SimulationConfig", menuName = "Frostborn/SimulationConfig")]
    public class SimulationConfig : ScriptableObject {
        [Header("Needs Decay per second")]
        public float HungerDecay = 0.5f;
        public float WarmthDecay = 0.2f;
        public float MoraleDecay = 0.05f;
        public float FatigueGain = 0.3f;

        [Header("Doctrine")]
        public float StoicismMoraleDecayMultiplier = 0.85f;
        public float FurnaceRadiusBonus = 1.15f;
        public float CraftSpeedBonus = 1.10f;

        [Header("Event System")]
        public float EventCheckInterval = 20f;
        public float EventProbability = 0.35f;

        [Header("Heat")]
        public float AmbientTemperature = -20f;
        public float CitizenComfortTemp = 5f;
        public float WarmthBonusPerTempDegree = 0.02f;
        public float HeatGridCellSize = 6f;
        public float HeatGridRebuildInterval = 2f;
        public float HeatFieldRebuildInterval = 3f;
        public int HeatFieldResolution = 48;

        [Header("Crafting")]
        public int MaxParallelCrafts = 4;
        public float BaseCraftSpeed = 1f;

        [Header("Day/Night")]
        public float DayLengthSeconds = 600f;

        [Header("Weather")]
        public float WeatherBaseDuration = 90f;
        public float WeatherTempModifierSnow = -5f;
        public float WeatherTempModifierBlizzard = -15f;

        [Header("Perishables")]
        public float BaseDecayPerMinute = 1f;
        public float ColdSlowMultiplier = 0.25f;

        [Header("Threats")]
        public float ThreatCheckInterval = 180f;
        public float ThreatProbability = 0.25f;
        public float WaveInterval = 240f;
        public float WaveIntensityGrowth = 1.15f;
        public float StructureBaseHealth = 100f;

        [Header("Telemetry")]
        public float TelemetryInterval = 10f;
        public int TelemetryBufferCapacity = 256;

        [Header("Balancing Targets")]
        public float TargetAvgHunger = 55f;
        public float TargetAvgWarmth = 65f;
        public float TargetAvgMorale = 60f;

        [Header("Balancing Clamp Multipliers")]
        public float MinNeedsDecayMultiplier = 0.6f;
        public float MaxNeedsDecayMultiplier = 1.4f;
        public float MinCraftSpeedMultiplier = 0.8f;
        public float MaxCraftSpeedMultiplier = 1.6f;
        public float MinResourceYieldMultiplier = 0.9f;
        public float MaxResourceYieldMultiplier = 1.5f;
        public float MinThreatFreqMultiplier = 0.5f;
        public float MaxThreatFreqMultiplier = 1.5f;
    }
}