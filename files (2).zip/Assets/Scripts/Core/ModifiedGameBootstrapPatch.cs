using UnityEngine;
using FrostbornRealms.Assets;

namespace FrostbornRealms {
    public class ModifiedGameBootstrapPatch : MonoBehaviour {
        // Attach this as sibling to the existing GameBootstrap if you want to guarantee fallback before Awake
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        static void PreScene() {
            FallbackAssetBootstrap.EnsureRuntimeFallback();
        }
    }
}