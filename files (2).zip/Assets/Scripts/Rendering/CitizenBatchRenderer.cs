using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Tasks;
using FrostbornRealms.ECS.Components;
using System.Collections.Generic;

namespace FrostbornRealms.Visual {
    public class CitizenBatchRenderer : MonoBehaviour {
        World world;
        Mesh quad;
        Material idleMat;
        Material workMat;
        static readonly int ColorID = Shader.PropertyToID("_Color");
        List<Matrix4x4> idleMatrices = new();
        List<Matrix4x4> workMatrices = new();

        void Awake(){
            world = World.DefaultGameObjectInjectionWorld;
            quad = BuildQuad();
            idleMat = new Material(Shader.Find("Unlit/Color")){ color = Color.cyan };
            workMat = new Material(Shader.Find("Unlit/Color")){ color = Color.yellow };
        }

        Mesh BuildQuad(){
            var m = new Mesh();
            m.vertices = new[]{
                new Vector3(-0.3f,0,0),
                new Vector3(0.3f,0,0),
                new Vector3(-0.3f,1f,0),
                new Vector3(0.3f,1f,0)
            };
            m.triangles = new[]{0,2,1,1,2,3};
            m.RecalculateNormals();
            return m;
        }

        void LateUpdate(){
            if(world == null || !world.IsCreated) return;
            idleMatrices.Clear();
            workMatrices.Clear();
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(CitizenTag), typeof(Position));
            using(var ents = q.ToEntityArray(Unity.Collections.Allocator.Temp)){
                foreach(var e in ents){
                    var pos = em.GetComponentData<Position>(e);
                    var mat = Matrix4x4.TRS(new Vector3(pos.Value.x, pos.Value.y, pos.Value.z),
                        Camera.main != null ? Camera.main.transform.rotation : Quaternion.identity,
                        Vector3.one);
                    if(em.HasComponent<AssignedTask>(e))
                        workMatrices.Add(mat);
                    else
                        idleMatrices.Add(mat);
                }
            }
            if(idleMatrices.Count>0)
                Graphics.DrawMeshInstanced(quad, 0, idleMat, idleMatrices);
            if(workMatrices.Count>0)
                Graphics.DrawMeshInstanced(quad, 0, workMat, workMatrices);
        }
    }
}