#if UNITY_EDITOR
using UnityEditor;
using System.Linq;

namespace FrostbornRealms.EditorTools {
    public static class ToggleLegacyDebugDefine {
        const string Define = "ENABLE_LEGACY_DEBUG";

        [MenuItem("Tools/Frostborn/Toggle Legacy Debug HUD")]
        public static void Toggle() {
            var targetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
            string defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(targetGroup);
            var list = defines.Split(';').Where(s=>!string.IsNullOrWhiteSpace(s)).ToList();
            if (list.Contains(Define)) {
                list.RemoveAll(d=>d==Define);
            } else {
                list.Add(Define);
            }
            PlayerSettings.SetScriptingDefineSymbolsForGroup(targetGroup, string.Join(";", list));
            UnityEditor.Compilation.CompilationPipeline.RequestScriptCompilation();
            UnityEngine.Debug.Log("[LegacyDebug] Toggled: " + (list.Contains(Define) ? "Enabled" : "Disabled"));
        }
    }
}
#endif