#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;
using System.Text;
using FrostbornRealms.Assets;

namespace FrostbornRealms.EditorTools {
    [InitializeOnLoad]
    public static class AutoGameSetup {
        const string MarkerFile = "Assets/ScriptableObjects/__AUTO_GENERATED.marker";
        const string ManifestPath = "Assets/ScriptableObjects/AssetManifest.asset";
        const string ModsRoot = "Assets/StreamingAssets/Mods/Auto";
        static AutoGameSetup() {
            if (!Directory.Exists("Assets/StreamingAssets")) Directory.CreateDirectory("Assets/StreamingAssets");
            if (!Directory.Exists(ModsRoot)) {
                Directory.CreateDirectory(ModsRoot);
                GenerateModJson();
            }
            if (!File.Exists(MarkerFile)) {
                Directory.CreateDirectory("Assets/ScriptableObjects");
                CreateManifestIfMissing();
                File.WriteAllText(MarkerFile, "auto-generated");
                AssetDatabase.Refresh();
            }
        }

        [MenuItem("Tools/Frostborn/Force Regenerate Auto Assets")]
        public static void ForceRegenerate() {
            Directory.CreateDirectory(ModsRoot);
            GenerateModJson(force:true);
            CreateManifestIfMissing(force:true);
            Debug.Log("[AutoSetup] Forced regeneration completed.");
        }

        static void CreateManifestIfMissing(bool force=false) {
            var manifest = AssetDatabase.LoadAssetAtPath<AssetManifest>(ManifestPath);
            if (manifest != null && !force) return;
            if (manifest == null) {
                manifest = ScriptableObject.CreateInstance<AssetManifest>();
                AssetDatabase.CreateAsset(manifest, ManifestPath);
            }
            manifest.AmbientClips = manifest.AmbientClips ?? new();
            manifest.SFXClips = manifest.SFXClips ?? new();
            manifest.Prefabs = manifest.Prefabs ?? new();
            manifest.Materials = manifest.Materials ?? new();
            manifest.Sprites = manifest.Sprites ?? new();

            // Simple colored materials
            AddMaterial(manifest, "mat_unlit_citizen", new Color(0,0.9f,1f));
            AddMaterial(manifest, "mat_unlit_resource", new Color(0.7f,0.5f,0.2f));
            AddMaterial(manifest, "mat_unlit_fire", new Color(1f,0.3f,0f));
            AddMaterial(manifest, "mat_unlit_generic", new Color(0.6f,0.6f,0.6f));

            AddPrefab(manifest, "fire_pit", PrimitiveType.Cylinder, new Color(0.4f,0.15f,0.05f), addLight:true);
            AddPrefab(manifest, "wood_pile", PrimitiveType.Cube, new Color(0.5f,0.35f,0.15f));
            AddPrefab(manifest, "stone_cluster", PrimitiveType.Cube, new Color(0.5f,0.5f,0.5f));
            AddPrefab(manifest, "berry_bush", PrimitiveType.Sphere, new Color(0.1f,0.6f,0.1f));

            // Silent audio
            AddSilentClip(manifest, "ambient_wind_loop");
            AddSilentClip(manifest, "ambient_day_01");
            AddSilentClip(manifest, "ambient_night_01");
            AddSilentClip(manifest, "sfx_click", ambient:false);
            AddSilentClip(manifest, "sfx_build_hammer", ambient:false);
            AddSilentClip(manifest, "sfx_gather_chop", ambient:false);
            AddSilentClip(manifest, "sfx_threat_wolf", ambient:false);

            EditorUtility.SetDirty(manifest);
            AssetDatabase.SaveAssets();
        }

        static void AddMaterial(AssetManifest manifest, string key, Color c) {
            if (manifest.Materials.Exists(m=>m.Key==key)) return;
            var mat = new Material(Shader.Find("Unlit/Color")) { color = c };
            AssetDatabase.CreateAsset(mat, $"Assets/Materials/{key}.mat");
            Directory.CreateDirectory("Assets/Materials");
            manifest.Materials.Add(new AssetManifest.MaterialEntry { Key = key, Material = mat });
        }

        static void AddPrefab(AssetManifest manifest, string key, PrimitiveType primitive, Color tint, bool addLight=false) {
            if (manifest.Prefabs.Exists(p=>p.Key==key)) return;
            var temp = GameObject.CreatePrimitive(primitive);
            temp.name = key;
            if (temp.TryGetComponent<Renderer>(out var r)) {
                var m = new Material(Shader.Find("Unlit/Color")) { color = tint };
                r.sharedMaterial = m;
            }
            if (addLight) {
                var l = new GameObject("Light").AddComponent<Light>();
                l.type = LightType.Point;
                l.range = 7;
                l.intensity = 2;
                l.transform.SetParent(temp.transform,false);
                l.transform.localPosition = new Vector3(0,1,0);
            }
            Directory.CreateDirectory("Assets/Prefabs");
            string path = $"Assets/Prefabs/{key}.prefab";
            var prefab = PrefabUtility.SaveAsPrefabAsset(temp, path);
            Object.DestroyImmediate(temp);
            manifest.Prefabs.Add(new AssetManifest.PrefabEntry { Key = key, Prefab = prefab });
        }

        static void AddSilentClip(AssetManifest manifest, string key, bool ambient=true) {
            if (ambient && manifest.AmbientClips.Exists(a=>a.Key==key)) return;
            if (!ambient && manifest.SFXClips.Exists(a=>a.Key==key)) return;
            var clip = AudioClip.Create(key, 44100, 1, 44100, false);
            if (ambient)
                manifest.AmbientClips.Add(new AssetManifest.AudioEntry { Key = key, Clip = clip });
            else
                manifest.SFXClips.Add(new AssetManifest.AudioEntry { Key = key, Clip = clip });
        }

        static void GenerateModJson(bool force=false) {
            WriteIfMissing(Path.Combine(ModsRoot, "items.json"), ItemsJson(), force);
            WriteIfMissing(Path.Combine(ModsRoot, "recipes.json"), RecipesJson(), force);
            WriteIfMissing(Path.Combine(ModsRoot, "events.json"), EventsJson(), force);
            WriteIfMissing(Path.Combine(ModsRoot, "doctrines.json"), DoctrinesJson(), force);
        }

        static void WriteIfMissing(string path, string content, bool force) {
            if (File.Exists(path) && !force) return;
            File.WriteAllText(path, content, Encoding.UTF8);
        }

        static string ItemsJson() {
            return @"{
  ""items"": [
    { ""id"":1, ""name"":""Wood"", ""category"":""fuel"", ""stackSize"":100 },
    { ""id"":2, ""name"":""Stone"", ""category"":""fuel"", ""stackSize"":100 },
    { ""id"":3, ""name"":""Berries"", ""category"":""food"", ""stackSize"":50 },
    { ""id"":4, ""name"":""Meat"", ""category"":""food"", ""stackSize"":50 },
    { ""id"":5, ""name"":""SpoiledFood"", ""category"":""food"", ""stackSize"":50 },
    { ""id"":6, ""name"":""Plank"", ""category"":""fuel"", ""stackSize"":100 },
    { ""id"":7, ""name"":""Pelt"", ""category"":""medicine"", ""stackSize"":40 },
    { ""id"":8, ""name"":""Medicine"", ""category"":""medicine"", ""stackSize"":40 }
  ]
}";
        }

        static string RecipesJson() {
            return @"{
  ""recipes"":[
    {
      ""id"":101,
      ""key"":""PlankFromWood"",
      ""craftTime"":6.0,
      ""inputs"":[{""item"":""Wood"",""count"":4}],
      ""outputs"":[{""item"":""Plank"",""count"":2}]
    },
    {
      ""id"":102,
      ""key"":""CookedMeat"",
      ""craftTime"":8.0,
      ""inputs"":[{""item"":""Meat"",""count"":2},{""item"":""Wood"",""count"":1}],
      ""outputs"":[{""item"":""Meat"",""count"":2}],
      ""effects"":[""morale+3"",""hunger-5""]
    },
    {
      ""id"":103,
      ""key"":""MedicineBlend"",
      ""craftTime"":10.0,
      ""inputs"":[{""item"":""Berries"",""count"":5},{""item"":""Pelt"",""count"":1}],
      ""outputs"":[{""item"":""Medicine"",""count"":1}],
      ""effects"":[""morale+2""]
    }
  ]
}";
        }

        static string EventsJson() {
            return @"{
  ""events"":[
    {
      ""key"":""ColdSnap"",
      ""choices"":[
        { ""key"":""Endure"", ""effects"":[""warmth-5"",""morale-2""] },
        { ""key"":""BurnFuel"", ""effects"":[""fuel-5"",""warmth+8""] }
      ]
    },
    {
      ""key"":""FoodSpoilage"",
      ""choices"":[
        { ""key"":""Accept"", ""effects"":[""food-4"",""morale-1""] },
        { ""key"":""Inspect"", ""effects"":[""morale+1""] }
      ]
    }
  ]
}";
        }

        static string DoctrinesJson() {
            return @"{
  ""doctrines"":[
    { ""key"":""Stoicism"", ""thresholds"":[{""progress"":100,""effect"":""morale_decay_mul:0.85""}] },
    { ""key"":""FurnaceMastery"", ""thresholds"":[{""progress"":120,""effect"":""heat_radius_mul:1.15""}] },
    { ""key"":""Logistics"", ""thresholds"":[{""progress"":90,""effect"":""craft_speed_mul:1.10""}] }
  ]
}";
        }
    }
}
#endif