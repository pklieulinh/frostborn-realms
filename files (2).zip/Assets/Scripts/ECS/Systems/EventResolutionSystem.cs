using Unity.Burst;
using Unity.Entities;
using UnityEngine;
using FrostbornRealms.Core;
using FrostbornRealms.Data;
using FrostbornRealms.Effects;

namespace FrostbornRealms.ECS.Systems {
    [BurstCompile]
    public partial struct EventResolutionSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        float timer;
        public void OnUpdate(ref SystemState state) {
            var cfg = ServiceLocator.Get<SimulationConfig>();
            timer += SystemAPI.Time.DeltaTime;
            if(timer < cfg.EventCheckInterval) return;
            timer = 0;
            var rng = ServiceLocator.Get<RandomService>();
            if(rng.Value.NextFloat() > cfg.EventProbability) return;
            Entity effectQueue = SystemAPI.GetSingletonEntity<EffectQueueTag>();
            var effectBuffer = state.EntityManager.GetBuffer<EffectToken>(effectQueue);
            if(EventRegistry.All.Count == 0) return;
            var ev = EventRegistry.All[rng.NextInt(0, EventRegistry.All.Count)];
            if(ev.Choices.Count>0){
                var choice = ev.Choices[0];
                foreach(var eff in choice.Effects){
                    effectBuffer.Add(new EffectToken{ Value = eff });
                }
                Debug.Log($"[Event] {ev.Key} -> {choice.Key}");
            } else {
                Debug.Log($"[Event] {ev.Key} (auto)");
            }
        }
    }
}