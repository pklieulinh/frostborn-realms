using UnityEngine;

namespace FrostbornRealms {
    [DefaultExecutionOrder(-10000)]
    public class OneClickPlayReadme : MonoBehaviour {
        void Start() {
            if (!PlayerPrefs.HasKey("FirstRunOneClick")) {
                Debug.Log("[OneClick] Auto assets generated. You can now press Play to start simulation.");
                PlayerPrefs.SetInt("FirstRunOneClick", 1);
                PlayerPrefs.Save();
            }
        }
    }
}