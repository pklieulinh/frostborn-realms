using UnityEngine;
using Unity.Entities;
using FrostbornRealms.Tasks;

namespace FrostbornRealms.Animation {
    public class EntityAnimator : MonoBehaviour {
        public enum AnimState { Idle, Gathering, Building, Crafting }
        AnimState state;
        World world;
        void Awake(){ world = World.DefaultGameObjectInjectionWorld; }
        void Update(){
            if(world == null || !world.IsCreated) return;
            // Stub: pick first citizen with task and derive state
            var em = world.EntityManager;
            var q = em.CreateEntityQuery(typeof(CitizenTag));
            using(var ents = q.ToEntityArray(Unity.Collections.Allocator.Temp)){
                if(ents.Length == 0){ state = AnimState.Idle; return; }
                foreach(var e in ents){
                    if(em.HasComponent<AssignedTask>(e)){
                        var t = em.GetComponentData<AssignedTask>(e);
                        state = t.Type switch {
                            TaskType.Gather => AnimState.Gathering,
                            TaskType.Build => AnimState.Building,
                            TaskType.Craft => AnimState.Crafting,
                            _ => AnimState.Idle
                        };
                        return;
                    }
                }
                state = AnimState.Idle;
            }
        }
        void OnGUI(){
            var rect = new Rect(Screen.width - 180, 10, 170, 60);
            GUILayout.BeginArea(rect, GUI.skin.box);
            GUILayout.Label("Animator Stub");
            GUILayout.Label("State: " + state);
            GUILayout.EndArea();
        }
    }
}