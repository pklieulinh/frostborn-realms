using Unity.Entities;
using Unity.Mathematics;
using FrostbornRealms.Navigation;
using Unity.Collections;
using FrostbornRealms.ECS.Components;

namespace FrostbornRealms.ECS.Systems {
    public partial struct PathfindingBuildGridSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            var navEntity = SystemAPI.GetSingletonEntity<NavGridTag>();
            var cfg = state.EntityManager.GetComponentData<NavGridConfig>(navEntity);
            var buf = state.EntityManager.GetBuffer<NavGridCell>(navEntity);
            if(buf.Length == cfg.Width * cfg.Height) return;
            buf.Clear();
            for(int i=0;i<cfg.Width * cfg.Height;i++){
                buf.Add(new NavGridCell{ Walkable = 1 });
            }
            foreach(var (pos, e) in SystemAPI.Query<RefRO<Position>>().WithEntityAccess()){
                if(state.EntityManager.HasComponent<NavObstacleTag>(e)){
                    if(TryWorldToIndex(pos.ValueRO.Value, cfg, out int ix, out int iy)){
                        int idx = iy * cfg.Width + ix;
                        if(idx>=0 && idx<buf.Length){
                            var cell = buf[idx];
                            cell.Walkable = 0;
                            buf[idx] = cell;
                        }
                    }
                }
            }
        }
        static bool TryWorldToIndex(float3 worldPos, NavGridConfig cfg, out int ix, out int iy){
            float3 rel = worldPos - cfg.Origin;
            ix = (int)math.floor(rel.x / cfg.CellSize);
            iy = (int)math.floor(rel.z / cfg.CellSize);
            if(ix<0||iy<0||ix>=cfg.Width||iy>=cfg.Height) return false;
            return true;
        }
    }

    public partial struct PathfindingSystem : ISystem {
        struct Node {
            public int X;
            public int Y;
            public float G;
            public float H;
            public int Parent;
            public byte Closed;
            public byte Opened;
        }

        public void OnCreate(ref SystemState state){
            state.EntityManager.AddBuffer<PathRequest>(SystemAPI.GetSingletonEntity<NavGridTag>());
        }
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            var navEntity = SystemAPI.GetSingletonEntity<NavGridTag>();
            var cfg = state.EntityManager.GetComponentData<NavGridConfig>(navEntity);
            var cells = state.EntityManager.GetBuffer<NavGridCell>(navEntity);
            var reqBuf = state.EntityManager.GetBuffer<PathRequest>(navEntity);
            if(reqBuf.Length == 0) return;

            int maxNodes = cfg.Width * cfg.Height;
            var nodes = new NativeArray<Node>(maxNodes, Allocator.Temp);
            var openList = new NativeList<int>(Allocator.Temp);

            for(int r=0;r<math.min(reqBuf.Length, 8); r++){
                var req = reqBuf[r];
                if(!state.EntityManager.Exists(req.Seeker)) continue;
                if(!SystemAPI.HasComponent<Position>(req.Seeker)) continue;
                var startPos = SystemAPI.GetComponent<Position>(req.Seeker).Value;
                if(!TryWorldToIndex(startPos, cfg, out int sx, out int sy)) continue;
                if(!TryWorldToIndex(req.Target, cfg, out int tx, out int ty)) continue;
                int startIdx = sy * cfg.Width + sx;
                int targetIdx = ty * cfg.Width + tx;
                for(int i=0;i<maxNodes;i++){
                    nodes[i] = default;
                }
                openList.Clear();
                nodes[startIdx] = new Node{ X=sx, Y=sy, G=0, H=Heuristic(sx,sy,tx,ty), Parent=-1, Opened=1 };
                openList.Add(startIdx);
                bool found = false;
                while(openList.Length>0){
                    int bestI = 0;
                    float bestF = float.MaxValue;
                    for(int i=0;i<openList.Length;i++){
                        var nd = nodes[openList[i]];
                        float f = nd.G + nd.H;
                        if(f < bestF){ bestF = f; bestI = i; }
                    }
                    int currentIdx = openList[bestI];
                    var current = nodes[currentIdx];
                    openList.RemoveAtSwapBack(bestI);
                    current.Closed = 1;
                    nodes[currentIdx] = current;
                    if(currentIdx == targetIdx){
                        found = true;
                        break;
                    }
                    Expand(currentIdx, tx, ty, cfg, cells, ref nodes, ref openList);
                }
                var pathEntity = req.Seeker;
                if(!state.EntityManager.HasComponent<PathResultTag>(pathEntity))
                    state.EntityManager.AddComponent<PathResultTag>(pathEntity);
                if(!state.EntityManager.HasBuffer<PathWaypoint>(pathEntity))
                    state.EntityManager.AddBuffer<PathWaypoint>(pathEntity);

                var wpBuf = state.EntityManager.GetBuffer<PathWaypoint>(pathEntity);
                wpBuf.Clear();

                if(found){
                    int idx = targetIdx;
                    while(idx != -1){
                        var nd = nodes[idx];
                        float3 w = IndexToWorld(nd.X, nd.Y, cfg);
                        wpBuf.Add(new PathWaypoint{ Position = w });
                        idx = nd.Parent;
                    }
                    // reverse
                    for(int i=0,j=wpBuf.Length-1; i<j; i++,j--){
                        var tmp = wpBuf[i]; wpBuf[i]=wpBuf[j]; wpBuf[j]=tmp;
                    }
                    if(!state.EntityManager.HasComponent<CurrentPath>(pathEntity))
                        state.EntityManager.AddComponentData(pathEntity, new CurrentPath{ Index = 0 });
                    else {
                        var cp = state.EntityManager.GetComponentData<CurrentPath>(pathEntity);
                        cp.Index = 0;
                        state.EntityManager.SetComponentData(pathEntity, cp);
                    }
                }
            }
            reqBuf.Clear();
            nodes.Dispose();
            openList.Dispose();
        }

        static void Expand(int idx, int tx, int ty, NavGridConfig cfg, DynamicBuffer<NavGridCell> cells, ref NativeArray<Node> nodes, ref NativeList<int> open){
            int w = cfg.Width;
            var baseNode = nodes[idx];
            int2[] dirs = {
                new int2(1,0), new int2(-1,0), new int2(0,1), new int2(0,-1),
                new int2(1,1), new int2(-1,1), new int2(1,-1), new int2(-1,-1)
            };
            foreach(var d in dirs){
                int nx = baseNode.X + d.x;
                int ny = baseNode.Y + d.y;
                if(nx<0||ny<0||nx>=cfg.Width||ny>=cfg.Height) continue;
                int nIdx = ny * w + nx;
                if(cells[nIdx].Walkable == 0) continue;
                var nd = nodes[nIdx];
                if(nd.Closed == 1) continue;
                float cost = baseNode.G + math.length(new float2(d.x,d.y));
                if(nd.Opened == 0 || cost < nd.G){
                    nd.X = nx; nd.Y = ny;
                    nd.G = cost;
                    nd.H = Heuristic(nx, ny, tx, ty);
                    nd.Parent = idx;
                    if(nd.Opened == 0){
                        nd.Opened = 1;
                        open.Add(nIdx);
                    }
                    nodes[nIdx] = nd;
                }
            }
        }

        static float Heuristic(int x, int y, int tx, int ty){
            return math.abs(x - tx) + math.abs(y - ty);
        }

        static bool TryWorldToIndex(float3 worldPos, NavGridConfig cfg, out int ix, out int iy){
            var rel = worldPos - cfg.Origin;
            ix = (int)math.floor(rel.x / cfg.CellSize);
            iy = (int)math.floor(rel.z / cfg.CellSize);
            if(ix<0||iy<0||ix>=cfg.Width||iy>=cfg.Height) return false;
            return true;
        }

        static float3 IndexToWorld(int x, int y, NavGridConfig cfg){
            return cfg.Origin + new float3((x+0.5f)*cfg.CellSize, 0, (y+0.5f)*cfg.CellSize);
        }
    }

    public partial struct CitizenMovementSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            foreach(var (pos, speed, cp, entity) in SystemAPI.Query<RefRW<Position>, MovementSpeed, RefRW<CurrentPath>>().WithEntityAccess()){
                if(!state.EntityManager.HasBuffer<PathWaypoint>(entity)) continue;
                var wps = state.EntityManager.GetBuffer<PathWaypoint>(entity);
                if(cp.ValueRO.Index >= wps.Length) continue;
                var target = wps[cp.ValueRO.Index].Position;
                float3 p = pos.ValueRO.Value;
                float3 dir = target - p;
                float dist = math.length(dir);
                if(dist < 0.05f){
                    var cpw = cp.ValueRO;
                    cpw.Index++;
                    cp.ValueRW = cpw;
                } else {
                    dir /= math.max(dist, 0.0001f);
                    p += dir * speed.Value * SystemAPI.Time.DeltaTime;
                    pos.ValueRW.Value = p;
                }
            }
        }
    }
}