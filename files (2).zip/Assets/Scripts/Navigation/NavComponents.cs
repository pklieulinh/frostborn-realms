using Unity.Entities;
using Unity.Mathematics;

namespace FrostbornRealms.Navigation {
    public struct NavGridTag : IComponentData {}
    public struct NavGridConfig : IComponentData {
        public int Width;
        public int Height;
        public float CellSize;
        public float3 Origin;
    }
    public struct NavGridCell : IBufferElementData {
        public byte Walkable;
    }
    public struct NavObstacleTag : IComponentData {}

    public struct PathRequest : IBufferElementData {
        public Entity Seeker;
        public float3 Target;
    }
    public struct PathWaypoint : IBufferElementData {
        public float3 Position;
    }
    public struct PathPendingTag : IComponentData {}
    public struct PathResultTag : IComponentData {}
    public struct CurrentPath : IComponentData {
        public int Index;
    }
    public struct MovementSpeed : IComponentData {
        public float Value;
    }
    public struct PathSeekerTag : IComponentData {}
}