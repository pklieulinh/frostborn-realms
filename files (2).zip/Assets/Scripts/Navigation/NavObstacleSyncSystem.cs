using Unity.Entities;
using FrostbornRealms.Future;
using FrostbornRealms.Navigation;
using FrostbornRealms.ECS.Components;
using Unity.Mathematics;

namespace FrostbornRealms.ECS.Systems {
    public partial struct NavObstacleSyncSystem : ISystem {
        int lastWallCount;
        public void OnCreate(ref SystemState state){ lastWallCount = 0; }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            int count = 0;
            foreach(var _ in SystemAPI.Query<WallSection>()) count++;
            if(!SystemAPI.HasSingleton<NavGridTag>()) return;
            if(count == lastWallCount) return;
            lastWallCount = count;
            var navEntity = SystemAPI.GetSingletonEntity<NavGridTag>();
            var cfg = SystemAPI.GetComponent<NavGridConfig>(navEntity);
            var buf = SystemAPI.GetBuffer<NavGridCell>(navEntity);
            if(buf.Length != cfg.Width * cfg.Height) return;
            // Reset walkable
            for(int i=0;i<buf.Length;i++){
                var c = buf[i];
                c.Walkable = 1;
                buf[i] = c;
            }
            foreach(var (wall, pos) in SystemAPI.Query<WallSection, Position>()){
                if(TryWorldToIndex(pos.Value, cfg, out int ix, out int iy)){
                    int idx = iy * cfg.Width + ix;
                    if(idx>=0 && idx<buf.Length){
                        var cell = buf[idx];
                        cell.Walkable = 0;
                        buf[idx] = cell;
                    }
                }
            }
        }
        static bool TryWorldToIndex(float3 worldPos, NavGridConfig cfg, out int ix, out int iy){
            float3 rel = worldPos - cfg.Origin;
            ix = (int)math.floor(rel.x / cfg.CellSize);
            iy = (int)math.floor(rel.z / cfg.CellSize);
            if(ix<0||iy<0||ix>=cfg.Width||iy>=cfg.Height) return false;
            return true;
        }
    }
}