using Unity.Entities;
using Unity.Collections;
using FrostbornRealms.Telemetry;
using FrostbornRealms.Inventory;
using FrostbornRealms.Doctrine;
using FrostbornRealms.Tasks;
using FrostbornRealms.Buildings;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.World;
using FrostbornRealms.Core;
using FrostbornRealms.ECS.Components;
using Unity.Mathematics;

namespace FrostbornRealms.ECS.Systems {
    public partial struct TelemetryCollectionSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            Entity telEntity = SystemAPI.GetSingletonEntity<TelemetryBufferTag>();
            var runtime = state.EntityManager.GetComponentData<TelemetryRuntime>(telEntity);
            runtime.TimeSinceLast += SystemAPI.Time.DeltaTime;
            var cfg = ServiceLocator.Get<SimulationConfig>();
            if(runtime.TimeSinceLast < runtime.Interval){
                state.EntityManager.SetComponentData(telEntity, runtime);
                return;
            }
            runtime.TimeSinceLast = 0;
            var buf = state.EntityManager.GetBuffer<TelemetrySample>(telEntity);
            if(buf.Length >= cfg.TelemetryBufferCapacity) buf.RemoveAt(0);

            float avgH=0, avgW=0, avgM=0;
            int count=0;
            foreach(var n in SystemAPI.Query<Needs>()){
                avgH += n.Hunger; avgW += n.Warmth; avgM += n.Morale; count++;
            }
            if(count>0){
                float inv = 1f/count;
                avgH*=inv; avgW*=inv; avgM*=inv;
            }

            var invEntity = SystemAPI.GetSingletonEntity<GlobalInventoryTag>();
            var cat = state.EntityManager.GetComponentData<CategoryAggregate>(invEntity);

            int craftOrders=0;
            foreach(var _ in SystemAPI.Query<Crafting.CraftOrder>()) craftOrders++;
            int sites=0;
            foreach(var _ in SystemAPI.Query<ConstructionSite>()) sites++;
            int nodes=0;
            foreach(var _ in SystemAPI.Query<ResourceNode>()) nodes++;

            byte weatherByte = 0;
            if(SystemAPI.HasSingleton<WeatherStateTag>()){
                var wsE = SystemAPI.GetSingletonEntity<WeatherStateTag>();
                var ws = state.EntityManager.GetComponentData<WeatherState>(wsE);
                weatherByte = (byte)ws.Current;
            }

            float moraleMult=1, heatBonus=1, craftBonus=1;
            foreach(var m in SystemAPI.Query<DoctrineModifier>()){
                moraleMult = m.MoraleDecayMultiplier;
                heatBonus = m.HeatRadiusBonus;
                craftBonus = m.CraftSpeedBonus;
            }

            buf.Add(new TelemetrySample{
                Time = (float)SystemAPI.Time.ElapsedTime,
                AvgHunger = avgH,
                AvgWarmth = avgW,
                AvgMorale = avgM,
                InventoryFuel = cat.Fuel,
                InventoryFood = cat.Food,
                InventoryMedicine = cat.Medicine,
                CraftOrders = craftOrders,
                ConstructionSites = sites,
                ResourceNodes = nodes,
                Weather = weatherByte,
                DoctrineMoraleMult = moraleMult,
                DoctrineHeatBonus = heatBonus,
                DoctrineCraftBonus = craftBonus
            });

            state.EntityManager.SetComponentData(telEntity, runtime);
        }
    }

    public partial struct TelemetryRollingStatsSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            Entity telEntity = SystemAPI.GetSingletonEntity<TelemetryBufferTag>();
            var runtime = state.EntityManager.GetComponentData<TelemetryRuntime>(telEntity);
            var buf = state.EntityManager.GetBuffer<TelemetrySample>(telEntity);
            if(buf.Length < 4){
                state.EntityManager.SetComponentData(telEntity, runtime);
                return;
            }
            float meanH=0, meanW=0, meanM=0;
            for(int i=0;i<buf.Length;i++){
                meanH += buf[i].AvgHunger;
                meanW += buf[i].AvgWarmth;
                meanM += buf[i].AvgMorale;
            }
            float inv = 1f / buf.Length;
            meanH*=inv; meanW*=inv; meanM*=inv;
            float varH=0,varW=0,varM=0;
            for(int i=0;i<buf.Length;i++){
                varH += math.pow(buf[i].AvgHunger - meanH,2);
                varW += math.pow(buf[i].AvgWarmth - meanW,2);
                varM += math.pow(buf[i].AvgMorale - meanM,2);
            }
            varH*=inv; varW*=inv; varM*=inv;
            runtime.RollingHungerAvg = meanH;
            runtime.RollingWarmthAvg = meanW;
            runtime.RollingMoraleAvg = meanM;
            runtime.RollingHungerStd = math.sqrt(varH);
            runtime.RollingWarmthStd = math.sqrt(varW);
            runtime.RollingMoraleStd = math.sqrt(varM);
            state.EntityManager.SetComponentData(telEntity, runtime);
        }
    }
}