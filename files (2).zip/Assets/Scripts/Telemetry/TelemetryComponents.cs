using Unity.Entities;

namespace FrostbornRealms.Telemetry {
    public struct TelemetryBufferTag : IComponentData {}
    public struct TelemetrySample : IBufferElementData {
        public float Time;
        public float AvgHunger;
        public float AvgWarmth;
        public float AvgMorale;
        public int InventoryFuel;
        public int InventoryFood;
        public int InventoryMedicine;
        public int CraftOrders;
        public int ConstructionSites;
        public int ResourceNodes;
        public byte Weather; // cast WeatherType
        public float DoctrineMoraleMult;
        public float DoctrineHeatBonus;
        public float DoctrineCraftBonus;
    }
    public struct TelemetryRuntime : IComponentData {
        public float TimeSinceLast;
        public float Interval;
        public float RollingHungerAvg;
        public float RollingWarmthAvg;
        public float RollingMoraleAvg;
        public float RollingHungerStd;
        public float RollingWarmthStd;
        public float RollingMoraleStd;
    }
}