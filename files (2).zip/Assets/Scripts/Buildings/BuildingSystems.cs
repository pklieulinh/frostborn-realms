using Unity.Entities;
using FrostbornRealms.Buildings;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;
using FrostbornRealms.Heat;
using Unity.Mathematics;
using FrostbornRealms.Core;
using FrostbornRealms.Threats;
using FrostbornRealms.Future;

namespace FrostbornRealms.ECS.Systems {
    public partial struct ConstructionSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var cfg = ServiceLocator.Get<SimulationConfig>();
            foreach(var (site, entity) in SystemAPI.Query<RefRW<ConstructionSite>>().WithEntityAccess()){
                var s = site.ValueRO;
                s.WorkRemaining -= SystemAPI.Time.DeltaTime;
                if(s.WorkRemaining <=0){
                    Build(ref state, s.KeyHash, cfg);
                    state.EntityManager.DestroyEntity(entity);
                } else {
                    site.ValueRW = s;
                }
            }
        }

        void Build(ref SystemState state, int keyHash, SimulationConfig cfg){
            if(keyHash == "FirePit".GetHashCode()){
                var heat = state.EntityManager.CreateEntity(typeof(HeatSource), typeof(Temperature), typeof(ECS.Components.Position), typeof(Building));
                state.EntityManager.SetComponentData(heat, new HeatSource{ Intensity = 60f, Radius = 18f });
                state.EntityManager.SetComponentData(heat, new Temperature{ Value = 0 });
                state.EntityManager.SetComponentData(heat, new ECS.Components.Position{ Value = new float3(0,0,0)});
                state.EntityManager.SetComponentData(heat, new Building{ KeyHash = keyHash });
                state.EntityManager.AddComponentData(heat, new BuildingHealth{ Value = cfg.StructureBaseHealth, Max = cfg.StructureBaseHealth });
            } else if(keyHash == "WallSection".GetHashCode()){
                var wall = state.EntityManager.CreateEntity(typeof(WallSection), typeof(ECS.Components.Position), typeof(Building));
                state.EntityManager.SetComponentData(wall, new WallSection{
                    Integrity = 1f,
                    MaxIntegrity = 1f,
                    DirtyNav = 1
                });
                state.EntityManager.SetComponentData(wall, new ECS.Components.Position{ Value = new float3(0,0,0)});
                state.EntityManager.SetComponentData(wall, new Building{ KeyHash = keyHash });
                state.EntityManager.AddComponentData(wall, new BuildingHealth{ Value = cfg.StructureBaseHealth * 0.5f, Max = cfg.StructureBaseHealth * 0.5f });
            } else if(keyHash == "Trap".GetHashCode()){
                var trap = state.EntityManager.CreateEntity(typeof(Trap), typeof(ECS.Components.Position), typeof(Building));
                state.EntityManager.SetComponentData(trap, new Trap{
                    Damage = 5f,
                    Cooldown = 15f,
                    TimeLeft = 3f
                });
                state.EntityManager.SetComponentData(trap, new ECS.Components.Position{ Value = new float3(0,0,0)});
                state.EntityManager.SetComponentData(trap, new Building{ KeyHash = keyHash });
                state.EntityManager.AddComponentData(trap, new BuildingHealth{ Value = cfg.StructureBaseHealth * 0.4f, Max = cfg.StructureBaseHealth * 0.4f });
            } else {
                var b = state.EntityManager.CreateEntity(typeof(Building), typeof(BuildingHealth));
                state.EntityManager.SetComponentData(b, new Building{ KeyHash = keyHash });
                state.EntityManager.SetComponentData(b, new BuildingHealth{
                    Value = cfg.StructureBaseHealth,
                    Max = cfg.StructureBaseHealth
                });
            }
        }
    }

    public static class BuildingUtility {
        public static bool GetCost(int keyHash, out (string item,int count)[] costs, out float work){
            if(keyHash == "FirePit".GetHashCode()){
                costs = new []{ ("Wood", 15), ("Stone", 8) };
                work = 25f;
                return true;
            }
            if(keyHash == "CookHouse".GetHashCode()){
                costs = new []{ ("Wood", 30), ("Stone", 20) };
                work = 40f;
                return true;
            }
            if(keyHash == "WallSection".GetHashCode()){
                costs = new []{ ("Wood", 10), ("Stone", 4) };
                work = 15f;
                return true;
            }
            if(keyHash == "Trap".GetHashCode()){
                costs = new []{ ("Wood", 8), ("Stone", 6) };
                work = 18f;
                return true;
            }
            costs = null;
            work = 0;
            return false;
        }
    }
}