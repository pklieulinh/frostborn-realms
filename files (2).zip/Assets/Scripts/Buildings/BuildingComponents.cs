using Unity.Entities;

namespace FrostbornRealms.Buildings {
    public struct BuildingBlueprintRequest : IComponentData {
        public int KeyHash;
        public float WorkRequired;
        public float WorkDone;
    }
    public struct ConstructionSite : IComponentData {
        public int KeyHash;
        public float WorkRemaining;
    }
    public struct Building : IComponentData {
        public int KeyHash;
    }
    public struct BuildingDefinition : IComponentData {
        public int KeyHash;
        public int HeatBonus;
    }
}