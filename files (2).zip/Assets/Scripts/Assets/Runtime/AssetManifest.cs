using UnityEngine;
using System.Collections.Generic;

namespace FrostbornRealms.Assets {
    [CreateAssetMenu(fileName="AssetManifest", menuName="Frostborn/AssetManifest")]
    public class AssetManifest : ScriptableObject {
        [System.Serializable] public class AudioEntry { public string Key; public AudioClip Clip; }
        [System.Serializable] public class PrefabEntry { public string Key; public GameObject Prefab; }
        [System.Serializable] public class MaterialEntry { public string Key; public Material Material; }
        [System.Serializable] public class SpriteEntry { public string Key; public Sprite Sprite; }

        public List<AudioEntry> AmbientClips;
        public List<AudioEntry> SFXClips;
        public List<PrefabEntry> Prefabs;
        public List<MaterialEntry> Materials;
        public List<SpriteEntry> Sprites;
    }

    public static class AssetResolver {
        static Dictionary<string, AudioClip> _ambient = new();
        static Dictionary<string, AudioClip> _sfx = new();
        static Dictionary<string, GameObject> _prefabs = new();
        static Dictionary<string, Material> _materials = new();
        static Dictionary<string, Sprite> _sprites = new();
        public static bool IsInitialized { get; private set; }

        public static void Initialize(AssetManifest manifest) {
            if (manifest == null || IsInitialized) return;
            _ambient.Clear(); _sfx.Clear(); _prefabs.Clear(); _materials.Clear(); _sprites.Clear();
            if (manifest.AmbientClips != null)
                foreach (var e in manifest.AmbientClips) if (!string.IsNullOrEmpty(e.Key) && e.Clip) _ambient[e.Key] = e.Clip;
            if (manifest.SFXClips != null)
                foreach (var e in manifest.SFXClips) if (!string.IsNullOrEmpty(e.Key) && e.Clip) _sfx[e.Key] = e.Clip;
            if (manifest.Prefabs != null)
                foreach (var e in manifest.Prefabs) if (!string.IsNullOrEmpty(e.Key) && e.Prefab) _prefabs[e.Key] = e.Prefab;
            if (manifest.Materials != null)
                foreach (var e in manifest.Materials) if (!string.IsNullOrEmpty(e.Key) && e.Material) _materials[e.Key] = e.Material;
            if (manifest.Sprites != null)
                foreach (var e in manifest.Sprites) if (!string.IsNullOrEmpty(e.Key) && e.Sprite) _sprites[e.Key] = e.Sprite;
            IsInitialized = true;
        }

        public static GameObject Prefab(string key) => _prefabs.TryGetValue(key, out var p) ? p : null;
        public static AudioClip Ambient(string key) => _ambient.TryGetValue(key, out var c) ? c : null;
        public static AudioClip SFX(string key) => _sfx.TryGetValue(key, out var c) ? c : null;
        public static Material Material(string key) => _materials.TryGetValue(key, out var m) ? m : null;
        public static Sprite Sprite(string key) => _sprites.TryGetValue(key, out var s) ? s : null;
    }
}