using UnityEngine;
using System.Collections.Generic;

namespace FrostbornRealms.Assets {
    public static class FallbackAssetBootstrap {
        static bool _done;
        public static void EnsureRuntimeFallback() {
            if (_done) return;
            if (AssetResolver.IsInitialized) { _done = true; return; }
            var manifest = ScriptableObject.CreateInstance<AssetManifest>();
            manifest.name = "RuntimeFallbackManifest";

            // Silent audio clips
            var silentClips = new Dictionary<string, AudioClip>();
            string[] clipKeys = { "ambient_wind_loop", "ambient_day_01", "ambient_night_01", "sfx_click", "sfx_build_hammer", "sfx_gather_chop", "sfx_threat_wolf" };
            foreach (var k in clipKeys) {
                silentClips[k] = MakeSilentClip(k);
            }
            manifest.AmbientClips = new List<AssetManifest.AudioEntry>();
            manifest.SFXClips = new List<AssetManifest.AudioEntry>();
            foreach (var kv in silentClips) {
                var entry = new AssetManifest.AudioEntry { Key = kv.Key, Clip = kv.Value };
                if (kv.Key.StartsWith("ambient")) manifest.AmbientClips.Add(entry);
                else manifest.SFXClips.Add(entry);
            }

            // Placeholder materials
            manifest.Materials = new List<AssetManifest.MaterialEntry> {
                new AssetManifest.MaterialEntry{ Key="mat_unlit_citizen", Material=MakeColorMat(new Color(0,0.9f,1f))},
                new AssetManifest.MaterialEntry{ Key="mat_unlit_resource", Material=MakeColorMat(new Color(0.7f,0.5f,0.2f))},
                new AssetManifest.MaterialEntry{ Key="mat_unlit_fire", Material=MakeColorMat(new Color(1f,0.3f,0f))},
                new AssetManifest.MaterialEntry{ Key="mat_unlit_generic", Material=MakeColorMat(new Color(0.6f,0.6f,0.6f))}
            };

            // Basic prefabs produced at runtime (primitive based)
            manifest.Prefabs = new List<AssetManifest.PrefabEntry>();
            manifest.Prefabs.Add(new AssetManifest.PrefabEntry { Key = "fire_pit", Prefab = MakePrimitivePrefab("FirePitPrefab", PrimitiveType.Cylinder, new Color(0.4f,0.15f,0.05f), addLight:true) });
            manifest.Prefabs.Add(new AssetManifest.PrefabEntry { Key = "wood_pile", Prefab = MakePrimitivePrefab("WoodPilePrefab", PrimitiveType.Cube, new Color(0.5f,0.35f,0.15f)) });
            manifest.Prefabs.Add(new AssetManifest.PrefabEntry { Key = "stone_cluster", Prefab = MakePrimitivePrefab("StoneClusterPrefab", PrimitiveType.Cube, new Color(0.5f,0.5f,0.5f)) });
            manifest.Prefabs.Add(new AssetManifest.PrefabEntry { Key = "berry_bush", Prefab = MakePrimitivePrefab("BerryBushPrefab", PrimitiveType.Sphere, new Color(0.1f,0.6f,0.1f)) });

            AssetResolver.Initialize(manifest);
            _done = true;
        }

        static AudioClip MakeSilentClip(string key) {
            int sampleRate = 44100;
            int length = sampleRate;
            var clip = AudioClip.Create(key, length, 1, sampleRate, false);
            var data = new float[length];
            clip.SetData(data, 0);
            return clip;
        }

        static Material MakeColorMat(Color c) {
            var m = new Material(Shader.Find("Unlit/Color"));
            m.color = c;
            return m;
        }

        static GameObject MakePrimitivePrefab(string name, PrimitiveType prim, Color tint, bool addLight=false) {
            var go = GameObject.CreatePrimitive(prim);
            go.name = name;
            if (go.TryGetComponent<Renderer>(out var r)) {
                r.sharedMaterial = MakeColorMat(tint);
            }
            if (addLight) {
                var l = new GameObject("Light").AddComponent<Light>();
                l.type = LightType.Point;
                l.range = 7;
                l.intensity = 2;
                l.transform.SetParent(go.transform,false);
                l.transform.localPosition = new Vector3(0,1,0);
            }
            go.SetActive(false);
            return go;
        }
    }
}