using UnityEngine;
using FrostbornRealms.Assets;

namespace FrostbornRealms {
    public class EnsureFallbackOnStart : MonoBehaviour {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterAssembliesLoaded)]
        static void Boot() {
            FallbackAssetBootstrap.EnsureRuntimeFallback();
        }
    }
}