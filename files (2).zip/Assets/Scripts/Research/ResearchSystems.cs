using Unity.Entities;
using FrostbornRealms.Research;
using FrostbornRealms.Core;
using FrostbornRealms.Doctrine;

namespace FrostbornRealms.ECS.Systems {
    public struct ResearchUnlockRequest : IComponentData {
        public int KeyHash;
    }

    public partial struct ResearchBootstrapSystem : ISystem {
        public void OnCreate(ref SystemState state){
            if(!SystemAPI.HasSingleton<ResearchStateTag>()){
                var st = state.EntityManager.CreateEntity(typeof(ResearchStateTag));
                state.EntityManager.AddBuffer<ResearchUnlocked>(st);
            }
            if(!SystemAPI.HasSingleton<ResearchPointsTag>()){
                var rp = state.EntityManager.CreateEntity(typeof(ResearchPointsTag));
                state.EntityManager.SetComponentData(rp, new ResearchPointsTag{ Points = 0 });
            }
        }
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){}
    }

    public partial struct ResearchPointGenerationSystem : ISystem {
        float timer;
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            if(!SystemAPI.HasSingleton<ResearchPointsTag>()) return;
            timer += SystemAPI.Time.DeltaTime;
            if(timer < 5f) return;
            timer = 0;
            int citizens = 0;
            foreach(var _ in SystemAPI.Query<FrostbornRealms.Tasks.CitizenTag>()) citizens++;
            float gain = 1f + citizens * 0.2f;
            if(SystemAPI.HasSingleton<DoctrineModifier>()){
                var mod = SystemAPI.GetSingleton<DoctrineModifier>();
                gain *= mod.CraftSpeedBonus; // minor synergy reuse
            }
            var rpEnt = SystemAPI.GetSingletonEntity<ResearchPointsTag>();
            var rp = SystemAPI.GetComponent<ResearchPointsTag>(rpEnt);
            rp.Points += gain;
            SystemAPI.SetComponent(rpEnt, rp);
        }
    }

    public partial struct ResearchUnlockSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            foreach(var (req, entity) in SystemAPI.Query<ResearchUnlockRequest>().WithEntityAccess()){
                if(!SystemAPI.HasSingleton<ResearchStateTag>() || !SystemAPI.HasSingleton<ResearchPointsTag>()){
                    state.EntityManager.DestroyEntity(entity);
                    continue;
                }
                var stateEnt = SystemAPI.GetSingletonEntity<ResearchStateTag>();
                var pointsEnt = SystemAPI.GetSingletonEntity<ResearchPointsTag>();
                // We need original key string — store hash only, brute force
                string key = null;
                foreach(var node in ResearchGraphAPI.AllNodes()){
                    if(node.Key.GetHashCode() == req.KeyHash){
                        key = node.Key;
                        break;
                    }
                }
                if(key != null){
                    ResearchRuntime.TryUnlock(state.EntityManager, stateEnt, pointsEnt, key, out _);
                }
                state.EntityManager.DestroyEntity(entity);
            }
        }
    }
}