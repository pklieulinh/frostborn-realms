using System.Collections.Generic;
using Unity.Entities;

namespace FrostbornRealms.Research {
    public struct ResearchStateTag : IComponentData {}
    public struct ResearchUnlocked : IBufferElementData {
        public int KeyHash;
    }
    public struct ResearchPointsTag : IComponentData {
        public float Points;
    }

    public class ResearchNode {
        public string Key;
        public string[] Requires;
        public float Cost;
        public string[] Effects;
    }

    public static class ResearchGraphAPI {
        static Dictionary<string, ResearchNode> nodes = new();
        static bool initialized;
        static void Init(){
            if(initialized) return;
            Add(new ResearchNode{
                Key="Heating_I",
                Requires=new string[0],
                Cost=30,
                Effects=new[]{ "heat_radius_mul:1.05" }
            });
            Add(new ResearchNode{
                Key="Heating_II",
                Requires=new[]{ "Heating_I" },
                Cost=60,
                Effects=new[]{ "heat_radius_mul:1.10" }
            });
            Add(new ResearchNode{
                Key="Logistics_I",
                Requires=new string[0],
                Cost=35,
                Effects=new[]{ "craft_speed_mul:1.05" }
            });
            Add(new ResearchNode{
                Key="TrapTech_I",
                Requires=new string[0],
                Cost=40,
                Effects=new[]{ "trap_damage_add:2" }
            });
            Add(new ResearchNode{
                Key="StoicMind_I",
                Requires=new string[0],
                Cost=50,
                Effects=new[]{ "morale_decay_mul:0.95" }
            });
            initialized = true;
        }
        static void Add(ResearchNode n){ nodes[n.Key]=n; }
        public static IEnumerable<ResearchNode> AllNodes(){ Init(); return nodes.Values; }
        public static bool TryGet(string key, out ResearchNode node){ Init(); return nodes.TryGetValue(key, out node); }
    }

    public static class ResearchRuntime {
        public static bool IsUnlocked(EntityManager em, Entity stateEntity, string key){
            if(!ResearchGraphAPI.TryGet(key, out _)) return false;
            var buf = em.GetBuffer<ResearchUnlocked>(stateEntity);
            int h = key.GetHashCode();
            for(int i=0;i<buf.Length;i++){
                if(buf[i].KeyHash == h) return true;
            }
            return false;
        }
        public static bool RequirementsMet(EntityManager em, Entity stateEntity, string key){
            if(!ResearchGraphAPI.TryGet(key, out var node)) return false;
            foreach(var r in node.Requires){
                if(!IsUnlocked(em, stateEntity, r)) return false;
            }
            return true;
        }
        public static bool TryUnlock(EntityManager em, Entity stateEntity, Entity pointsEntity, string key, out string error){
            error = null;
            if(!ResearchGraphAPI.TryGet(key, out var node)){ error="not_found"; return false; }
            if(IsUnlocked(em, stateEntity, key)){ error="already"; return false; }
            if(!RequirementsMet(em, stateEntity, key)){ error="requirements"; return false; }
            var pts = em.GetComponentData<ResearchPointsTag>(pointsEntity);
            if(pts.Points < node.Cost){ error="points"; return false; }
            pts.Points -= node.Cost;
            em.SetComponentData(pointsEntity, pts);
            em.GetBuffer<ResearchUnlocked>(stateEntity).Add(new ResearchUnlocked{ KeyHash = key.GetHashCode() });
            ApplyEffects(em, node.Effects);
            return true;
        }

        static void ApplyEffects(EntityManager em, string[] effects){
            if(effects == null) return;
            // Effects applied onto DoctrineModifier entity or create ResearchModifierTag aggregator
            DoctrineModifierUtil.ApplyResearchEffects(em, effects);
        }
    }

    public static class DoctrineModifierUtil {
        public static void ApplyResearchEffects(EntityManager em, string[] effects){
            if(!em.CreateEntityQuery(typeof(FrostbornRealms.Doctrine.DoctrineModifier)).IsEmpty){
                var ent = em.GetSingletonEntity<FrostbornRealms.Doctrine.DoctrineModifier>();
                var mod = em.GetComponentData<FrostbornRealms.Doctrine.DoctrineModifier>(ent);
                foreach(var e in effects){
                    var parts = e.Split(':');
                    if(parts.Length !=2) continue;
                    switch(parts[0]){
                        case "heat_radius_mul":
                            if(float.TryParse(parts[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var hr))
                                mod.HeatRadiusBonus *= hr;
                            break;
                        case "craft_speed_mul":
                            if(float.TryParse(parts[1], out var cs))
                                mod.CraftSpeedBonus *= cs;
                            break;
                        case "morale_decay_mul":
                            if(float.TryParse(parts[1], out var md))
                                mod.MoraleDecayMultiplier *= md;
                            break;
                        case "trap_damage_add":
                            // store in a separate component? quick hack: average into HeatRadiusBonus (not ideal)
                            break;
                    }
                }
                em.SetComponentData(ent, mod);
            }
        }
    }
}