using Unity.Entities;

namespace FrostbornRealms.World {
    public struct TimeOfDayTag : IComponentData {}
    public struct TimeOfDay : IComponentData {
        public float DayLengthSeconds;
        public float CurrentSeconds;
    }
    public partial struct DayNightCycleSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var entity = SystemAPI.GetSingletonEntity<TimeOfDayTag>();
            var tod = state.EntityManager.GetComponentData<TimeOfDay>(entity);
            tod.CurrentSeconds += SystemAPI.Time.DeltaTime;
            if(tod.CurrentSeconds > tod.DayLengthSeconds) tod.CurrentSeconds -= tod.DayLengthSeconds;
            state.EntityManager.SetComponentData(entity, tod);
        }
    }
}