using Unity.Entities;
using FrostbornRealms.Core;

namespace FrostbornRealms.World {
    public enum WeatherType : byte { Clear, Snow, Blizzard }
    public struct WeatherStateTag : IComponentData {}
    public struct WeatherState : IComponentData {
        public WeatherType Current;
        public float TimeRemaining;
    }
    public partial struct WeatherCycleSystem : ISystem {
        public void OnCreate(ref SystemState state){}
        public void OnDestroy(ref SystemState state){}
        public void OnUpdate(ref SystemState state){
            var cfg = ServiceLocator.Get<SimulationConfig>();
            var e = SystemAPI.GetSingletonEntity<WeatherStateTag>();
            var ws = state.EntityManager.GetComponentData<WeatherState>(e);
            ws.TimeRemaining -= SystemAPI.Time.DeltaTime;
            if(ws.TimeRemaining <=0){
                ws.Current = Next(ws.Current);
                ws.TimeRemaining = cfg.WeatherBaseDuration;
            }
            state.EntityManager.SetComponentData(e, ws);
        }
        WeatherType Next(WeatherType cur){
            return cur switch {
                WeatherType.Clear => WeatherType.Snow,
                WeatherType.Snow => WeatherType.Blizzard,
                WeatherType.Blizzard => WeatherType.Clear,
                _ => WeatherType.Clear
            };
        }
    }
}