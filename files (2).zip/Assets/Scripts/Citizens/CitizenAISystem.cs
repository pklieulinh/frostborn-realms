using Unity.Entities;
using FrostbornRealms.Tasks;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.Buildings;

namespace FrostbornRealms.ECS.Systems {
    public partial struct CitizenAISystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state){
            var queueEntity = SystemAPI.GetSingletonEntity<TaskQueueTag>();
            var queue = state.EntityManager.GetBuffer<TaskRequest>(queueEntity);
            // Simple heuristic: if any resource node exists and queue small, enqueue gather
            if(queue.Length < 5){
                foreach(var (node, entity) in SystemAPI.Query<ResourceNode>().WithEntityAccess()){
                    queue.Add(new TaskRequest{
                        Type = TaskType.Gather,
                        TargetEntity = entity
                    });
                    break;
                }
                foreach(var (site, entity) in SystemAPI.Query<ConstructionSite>().WithEntityAccess()){
                    queue.Add(new TaskRequest{
                        Type = TaskType.Build,
                        TargetEntity = entity
                    });
                    break;
                }
            }
        }
    }
}