using Unity.Entities;

namespace FrostbornRealms.Citizens {
    // Placeholder for future citizen-specific data (skills, traits)
    public struct CitizenStats : IComponentData {
        public float Efficiency;
    }
}