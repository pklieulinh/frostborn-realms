using Unity.Entities;
using Unity.Mathematics;
using FrostbornRealms.ResourceSystem;
using FrostbornRealms.Inventory;
using FrostbornRealms.Data;

namespace FrostbornRealms.ECS.Systems {
    public partial struct GatheringExecutionSystem : ISystem {
        public void OnCreate(ref SystemState state) {}
        public void OnDestroy(ref SystemState state) {}
        public void OnUpdate(ref SystemState state) {
            var ecb = new EntityCommandBuffer(Unity.Collections.Allocator.Temp);
            foreach(var (task, entity) in SystemAPI.Query<RefRW<GatherTask>>().WithEntityAccess()){
                if(!state.EntityManager.Exists(task.ValueRO.Node)){
                    ecb.DestroyEntity(entity);
                    continue;
                }
                var t = task.ValueRO;
                t.WorkRemaining -= SystemAPI.Time.DeltaTime;
                if(t.WorkRemaining <=0){
                    t.WorkRemaining = 1.5f;
                    if(state.EntityManager.HasComponent<ResourceNode>(t.Node)){
                        var rn = state.EntityManager.GetComponentData<ResourceNode>(t.Node);
                        rn.Remaining -= t.OutputPerCycle;
                        state.EntityManager.SetComponentData(t.Node, rn);
                        GlobalInventoryAPI.Add(t.OutputItemId, t.OutputPerCycle);
                        if(rn.Remaining <=0){
                            ecb.DestroyEntity(t.Node);
                            ecb.DestroyEntity(entity);
                            continue;
                        }
                    }
                }
                task.ValueRW = t;
            }
            ecb.Playback(state.EntityManager);
        }
    }

    public static class GatheringUtility {
        public static bool MapResource(int resourceKey, out int itemId, out int perCycle){
            var name = resourceKey switch {
                var k when k == ResourceNodeKeys.WoodPile => "Wood",
                var k when k == ResourceNodeKeys.BerryBush => "Berries",
                var k when k == ResourceNodeKeys.StoneCluster => "Stone",
                _ => null
            };
            perCycle = 3;
            itemId = 0;
            if(name == null) return false;
            var def = ItemRegistry.All.Find(x=>x.Name==name);
            if(def==null) return false;
            itemId = def.Id;
            return true;
        }
    }
}