using Unity.Entities;

namespace FrostbornRealms.ResourceSystem {
    public static class ResourceNodeKeys {
        public static readonly int WoodPile = "WoodPile".GetHashCode();
        public static readonly int BerryBush = "BerryBush".GetHashCode();
        public static readonly int StoneCluster = "StoneCluster".GetHashCode();
    }
    public struct ResourceNode : IComponentData {
        public int ResourceKey;
        public int Remaining;
    }
    public struct GatherTask : IComponentData {
        public Entity Node;
        public float WorkRemaining;
        public int OutputItemId;
        public int OutputPerCycle;
    }
}