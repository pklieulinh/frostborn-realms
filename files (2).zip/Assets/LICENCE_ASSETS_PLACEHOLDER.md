# Asset Licensing Placeholder

This project auto-generates placeholder assets (prefabs, materials, silent audio) for immediate play.

When you replace placeholders with real assets, update this file with:
- Source name
- URL
- License (CC0, CC-BY 4.0, etc.)
- Attribution (if required)
- Date imported
- Notes (modifications, compression)

Recommended free sources:
- Kenney (https://kenney.nl/assets) - CC0
- Quaternius (https://quaternius.com/) - CC0
- Poly Haven (https://polyhaven.com/) - CC0
- AmbientCG (https://ambientcg.com/) - CC0
- OpenGameArt (verify each asset's license)

Do not mix GPL assets into a proprietary/commercial distribution.

Replace this placeholder once real assets are integrated.