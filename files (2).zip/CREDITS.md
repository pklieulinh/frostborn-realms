# Credits & Attributions (Provisional)

This file aggregates attributions for assets that are not CC0.

(Example placeholders—update after actual import)
- Game-icons.net (CC-BY 3.0): UI symbolic icons.
- Freesound.org (user: <author>) snow_wind_loop.wav (CC-BY 4.0).

Update this list immediately when importing any CC-BY or similar licensed asset.